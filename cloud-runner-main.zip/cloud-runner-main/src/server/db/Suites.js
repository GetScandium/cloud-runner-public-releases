const { Schema } = require("redis-om");

const suitesSchema = new Schema("suites", {
  id: { type: 'string' },
  project_id: { type: 'string' },
  suite_id: { type: 'string' },
  starting_url: { type: 'string' },
  source: { type: 'string' },
  browser: { type: 'string' },
  browser_version: { type: 'string' },
  operating_system: { type: 'string' },
  operating_system_version:  { type: 'string' },
  is_mobile: { type: 'boolean' },
  duration: { type: 'number' },
  started_at:  { type: 'number' },
  finished_at: { type: 'number' },
  status: { type: 'string' },
  running_status: { type: 'string' },
  summary: { type: 'string' },
  results: { type: 'string[]' },
  name: { type: 'string' },
}, {
  dataStructure: 'HASH',
})

module.exports = suitesSchema;
