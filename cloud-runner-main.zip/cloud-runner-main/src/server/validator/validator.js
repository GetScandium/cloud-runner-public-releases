const { checkSchema, validationResult } = require("express-validator");
const ApiService = require("../../services/api.service");


const validate = (schema) => async (req, res, next) => {
  await Promise.all(checkSchema(schema).map(validation => validation.run(req)));
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }

  const errs = errors.array();

  return res.status(400).json({
    message: errs[0].msg,
    errors: errs,
    status: 400
  })
};

const validateCreateTest = validate({
  test_id: {
    in: ["body"],
    isUUID: true,
    custom: {
      options: async (test_id, { req }) => {
        const apiService = new ApiService(req.api_token);
        const { project_id, folder_id } = req.body;

        const { data: testcase } = await apiService.getTestData(project_id, test_id, folder_id);

        if (!testcase) throw new Error("Could not find the test case" );

        req.body.testcase = testcase;

        return true;
      }
    }
  },
  project_id: {
    in: ["body"],
    isUUID: true,
  },
  folder_id: {
    in: ["body"],
    isUUID: true,
    optional: true
  },
  screeshot: {
    in: ["body"],
    isBoolean: true,
    toBoolean: true,
    optional: true
  },
  strategy: {
    in: ["body"],
    isIn: { options: [['await', 'callback']] },
    optional: true
  },
  starting_url: {
    in: ["body"],
    isURL: true,
    optional: true
  },
  browser: {
    in: ["body"],
    isIn: { options: [["firefox", "chrome", "edge"]]},
    optional: { options: { nullable: true, checkFalsy: true }}
  },
  variables: {
    in: ["body"],
    isObject: { errorMessage: "variables should an object of key-value pair" },
    optional: { options: { nullable: true, checkFalsy: true } }
  },
  hub_url: {
    in: ["body"],
    isString: true,
    isURL: true,
    optional: true,
  },
  source: {
    in: ["body"],
    isString: true,
    isIn: { options: [["schedule", "remote"]]},
    optional: true,
  },
})

const validateDataTest = validate({
  test_id: {
    in: ["body"],
    isUUID: true,
    custom: {
      options: async (test_id, { req }) => {
        const apiService = new ApiService(req.api_token);
        const { project_id, folder_id } = req.body;

        const { data: testcase } = await apiService.getTestData(project_id, test_id, folder_id);

        if (!testcase) throw new Error("Could not find the test case" );

        if (!Array.isArray(testcase.data_source) || !testcase.data_source) {
          throw new Error("Data source not available")
        }

        req.body.data_source = testcase.data_source
        delete testcase.data_source;
        req.body.testcase = testcase;

        return true;
      }
    }
  },
  project_id: {
    in: ["body"],
    isUUID: true,
  },
  folder_id: {
    in: ["body"],
    isUUID: true,
    optional: true
  }
})

const validateCreateSuite = validate({
  suite_id: {
    in: ["body"],
    isUUID: true,
    custom: {
      options: async (suite_id, { req }) => {
        const apiService = new ApiService(req.api_token);
        const { project_id, folder_id } = req.body;

        const { data: suitecase } = await apiService.getSuiteData(project_id, suite_id);

        if (!suitecase) throw new Error("Could not find the suite case" );

        req.body.suitecase = suitecase;

        return true;
      }
    }
  },
  project_id: {
    in: ["body"],
    isUUID: true,
    custom: {
      options: async (project_id, { req }) => {
        const apiService = new ApiService(req.api_token);

        const { data: envs } = await apiService.getSuiteEnvironment(project_id);

        if (!envs.length) throw new Error("Could not find env environments")

        req.body.envs = envs;

        return true;
      }
    }
  },
  strategy: {
    in: ["body"],
    isString: true,
    isIn: { options: [["callback", "await"]]},
    optional: true,
  },
  retry: {
    in: ["body"],
    isInt: true,
    optional: true,
  },
  run_type: {
    in: ["body"],
    optional: true,
    isIn: { options: [["sequential", "parallel"]]}
  },
  hub_url: {
    in: ["body"],
    isString: true,
    isURL: true,
    optional: true,
  },
  source: {
    in: ["body"],
    isString: true,
    isIn: { options: [["schedule", "remote"]]},
    optional: true,
  },
})

module.exports = {
  validateCreateSuite, validateCreateTest, validateDataTest
}
