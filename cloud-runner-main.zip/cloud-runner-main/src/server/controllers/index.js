const TestRunner = require("../../cloud-runner/testRunner");
const SuiteRunner = require("../../cloud-runner/suiteRunner");
const ApiService = require("../../services/api.service");
const PulumiService = require("../services/pulumi.service");
const DataDriven = require("../../cloud-runner/dataDriven");
const runSchema = require("../db/Runs");
const { client } = require("../db");
const { Repository, EntityId } = require("redis-om");
const suitesSchema = require("../db/Suites");
const Sentry = require("@sentry/node");
const { default: axios } = require("axios");
const SeleniumTestConverter = require("../../test-generator/selenium");

const apiService = new ApiService()

const instantiateTest = async (req, res) => {
  const { user_id, browsers } = req.body;
  const pulumiService = new PulumiService();

  try {

    await pulumiService.initializeStack(user_id, ["chrome", "firefox"]);

    const instance = await pulumiService.createOrUpdateStack({}, user_id);

    const hub = instance.data.outputs.hubIp;

    const testcase = apiService.getTestData();

    const runResult = await Promise.all(["chrome", "firefox"].map(async browser => {
      const testRunner = new TestRunner(testcase, browser, hub.value );

      await testRunner.initializeDriver();

      const data = await testRunner.run();

      return data.result;
    }))

    res.status(200).json({ message: "Test completed", results: runResult });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "something went wrong" })
  } finally {
    await pulumiService.removeStack(user_id);
  }
}

const destroyServices = async (req, res) => {
  const { user_id } = req.body;

  try {
    await pulumiService.removeStack(user_id, ["chrome", "firefox"]);

    res.status(200).json({ message: "Test completed", results: runResult });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "something went wrong" })
  }
}

const runTest = async (req, res) => {
  const { testcase, browser, strategy = "await", test_id, project_id, retry = 0,  hub_ip, screenshot = false, starting_url, variables = {}, source } = req.body;

  try {
    const apiService = new ApiService(req.api_token);

    let { data: globalVariables } = await apiService.getGlobalVariables(project_id);
    const newVariables = variables

    for (let key in newVariables) {
      const idx = globalVariables.findIndex(variable => variable.name === key);

      if (idx >= 0) {
        globalVariables[idx] = {
          name: key,
          value: newVariables[key]
        }
      } else {
        globalVariables = [
          ...globalVariables,
          {
            name: key,
            value: newVariables[key]
          }
        ]
      }
    }

    if (testcase.data_source && testcase.data_source.length) {
      const dataDriven = new DataDriven(testcase);


      const suite = dataDriven.buildSuite();

      const suiteRunner = new SuiteRunner(suite, { browser: browser || testcase.browser }, apiService);

      const entity = await suiteRunner.initializeSuiteResult()

      if (strategy === "await") {
        const { result } = await suiteRunner.run();

        await apiService.sendSuiteResult({ ...result, type: "test-case", source }, project_id)

        return res.status(200).json({
          message: "Suite run successfully",
          data: {
            execution_id: entity[EntityId],
            started_at: result.started_at,
            finished_at: result.fruninished_at,
            duration: result.duration,
            running_status: result.running_status,
            summary: result.summary,
            status: result.status,
            browser: result.browser,
            source: result.source,
            name: result.name
          },
        })
      } else {
        suiteRunner.run().then(async run => {
          await apiService.sendSuiteResult({ ...run.result, type: "test-case", source }, project_id)
        }).catch(error => {
          Sentry.captureException(error, "Faild suite run!");
          apiService.sendSuiteRunError(error, "Suite run failed")
        })
  
        return res.status(200).json({
          message: "test is running in suite, you will be notified when it is completed",
          data: { 
            source: "remote",
            browser: suiteRunner.suiteResult.browser, 
            execution_id: entity[EntityId], 
            status: suiteRunner.suiteResult.status, 
            running_status: suiteRunner.suiteResult.running_status, 
            name: suiteRunner.suiteResult.name,
            started_at: suiteRunner.suiteResult.started_at,
            finished_at: suiteRunner.suiteResult.finished_at,
            duration: suiteRunner.suiteResult.duration,
          }
        })
      }

    } else {
      const testRunner = new TestRunner(testcase, browser, starting_url, hub_ip, globalVariables);

      const entity = await testRunner.initializeDriver()

      console.log('We get here!!');
      if (!testRunner.driver) throw new Error("Unable to initialize driver")

      
      if (strategy === "await") {
        const result = await testRunner.run(retry, screenshot);
  
        apiService.sendTestResult(result.result, { test_id, project_id }).then(res => {
          apiService.sendLogs({ value: result.logs.console, type: "console", project_id, run_id: entity[EntityId] }).then(() => console.log("sent logs")).catch((err) => console.log(err))
        }).catch(err => console.log(err, "test result send"))

  
        return res.status(200).json({
          data: result,
          message: "Test run completed"
        })
      } else {
        testRunner.run(retry, screenshot).then(
          ({ result, logs }) => {
            apiService.sendTestResult(result, { test_id, project_id }).then(res => {
              apiService.sendLogs({ value: logs.console, type: "console", project_id, run_id: entity[EntityId] }).then(() => console.log("sent logs")).catch((err) => console.log(err))
            });
          }
        ).catch(
          (error) => {
            Sentry.captureException(error, "Test run failed!");
            apiService.sendTestRunError(error, "Test run failed");
          }
        )
  
        return res.status(200).json({
          message: "test is running, you will be notified when it is completed",
          execution_id: entity[EntityId]
        })
      }
    }

    

  } catch (error) {
    console.log("Error intializing: ", error);
    Sentry.captureException(error, "Error running test!");
    return res.status(500).json(error);
  }
}

const getTestCurrentResult = async (req, res) => {
  const { execution_id } = req.params;

  try {
    const runRepo = new Repository(runSchema, client);

    const entity = await runRepo.fetch(execution_id);

    return res.status(200).json({
      message: "Result fetched successfully",
      data: {
        ...entity,
        steps: entity.steps.map(s => JSON.parse(s))
      }
    })
  } catch (error) {
    Sentry.captureException(error, "Error getting test live result!");
    console.log(error);
    return res.status(500).json(error);
  }
}

const getSuiteCurrentResult = async (req, res) => {
  const { execution_id } = req.params;

  try {
    const suiteRepo = new Repository(suitesSchema, client);

    const entity = await suiteRepo.fetch(execution_id);

    return res.status(200).json({
      message: "Result fetched successfully",
      data: {
        ...entity,
        steps: entity.results.map(s => JSON.parse(s))
      }
    })
  } catch (error) {
    Sentry.captureException(error, "Error get suite live result!");
    console.log(error);
    return res.status(500).json(error);
  }
}

const runSuite = async (req, res) => {
  const { suitecase, envs, strategy = "await", project_id, run_type, hub_url, retry, screenshot, source } = req.body;

  try {
    const apiService = new ApiService(req.api_token);

    let testcases = [];

    if (strategy === "await") {
      executions = []
      const runs = await Promise.all(suitecase.environment_ids.map(async env_id => {
        const env = envs?.find(({ id }) => id === env_id);
        const _testcases = testcases.length > 0 ? testcases : await Promise.all(suitecase.test_ids.map(async test_id => {
          const res = await apiService.getTestData(project_id, test_id);

          return res.data;
        }))
        
        _testcases.forEach(testcase => {
          if (testcase.data_source && testcase.data_source.length) {
            const dataDrive = new DataDriven(testcase);

            dataDrive.buildSuite().testcases.forEach(tc => {
              testcases.push(tc);
            });
          } else {
            testcases.push(testcase);
          }
        })

        const execution_type = run_type || suitecase.execution_type

        const suiteRunner = new SuiteRunner({ ...suitecase, testcases }, env, execution_type);

        const entity = await suiteRunner.initializeSuiteResult()

        executions.push({ browser: env.browser, source: "remote", execution_id: entity[EntityId] });

        const run = await suiteRunner.run(retry, screenshot);

        await apiService.sendSuiteResult({ ...run.result, source }, project_id);

        return run.result;
      }))

      
      await Promise.all(runs.map(run => {
        const { result } = run;
        const indx = executions.findIndex(exec => exec.execution_id === run.id);

        executions[indx] = {
          ...executions[indx],
          started_at: result.started_at,
          finished_at: result.finished_at,
          duration: result.duration,
          running_status: result.running_status,
          summary: result.summary,
          status: result.status,
          name: result.name,
        }

        apiService.sendSuiteResult(result, project_id)
      })) 

      return res.status(200).json({ data: { executions }, message: "Suite run completed" })
    } else {
      let executions = [];
      const runners = await Promise.all(suitecase.environment_ids.map(async env_id => {
        const env = envs?.find(({ id }) => id === env_id);
        const _testcases = testcases.length > 0 ? testcases : await Promise.all(suitecase.test_ids.map(async test_id => {
          const res = await apiService.getTestData(project_id, test_id);

          return res.data;
        }))
        
        _testcases.forEach(testcase => {
          if (testcase.data_source && testcase.data_source.length) {
            const dataDrive = new DataDriven(testcase);

            dataDrive.buildSuite().testcases.forEach(tc => {
              testcases.push(tc);
            });
          } else {
            testcases.push(testcase);
          }
        })

        const suiteRunner = new SuiteRunner({ ...suitecase, testcases }, env, run_type);

        const entity = await suiteRunner.initializeSuiteResult()

        executions.push({ 
          source: "remote",
          browser: suiteRunner.suiteResult.browser, 
          execution_id: entity[EntityId], 
          status: suiteRunner.suiteResult.status, 
          running_status: suiteRunner.suiteResult.running_status, 
          name: suiteRunner.suiteResult.name,
          started_at: suiteRunner.suiteResult.started_at,
          finished_at: suiteRunner.suiteResult.finished_at,
          duration: suiteRunner.suiteResult.duration,
        });

        return suiteRunner;
      }))


      Promise.all(runners.map(async runner => {
        const { result } = await runner.run()

        apiService.sendSuiteResult({ ...result, source }, project_id)

        return result;
      })).then(async runs => {
        await Promise.all(runs.map(run => apiService.sendSuiteResult(run, project_id)))
        
      }).catch(error => {
        Sentry.captureException(error, "Suite run failed");
        apiService.sendSuiteRunError(error, "Suite run failed")
      })

      return res.status(200).json({
        message: "test is running, you will be notified when it is completed",
        executions
      })
    }
    
  } catch (error) {
    Sentry.captureException(error, "Error running suite!");
    console.log(error);
    return res.status(500).json({
      message: "Something went wrong"
    })
  }
}

const getSeleniumCode = async (req, res) => {
  const { testcase, starting_url, browser } = req.body;

  try {
    const seleniumTestConverter = new SeleniumTestConverter(testcase, browser, starting_url)

    seleniumTestConverter.initialize()

    const code = seleniumTestConverter.run();

    return res.status(200).json({
      message: "Selenium code generated successfully",
      data: {
        code
      }
    })
  } catch (error) {
    console.log(error);
    return res.status(500).json({
      message: "Something went wrong"
    })
  }
}

module.exports = {
  instantiateTest, destroyServices, runTest, runSuite, getTestCurrentResult, getSuiteCurrentResult, getSeleniumCode
}
