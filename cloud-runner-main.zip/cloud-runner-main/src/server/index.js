const express = require("express");
const { config } = require("dotenv");
const Sentry = require("@sentry/node");

config()

const { runTest, runSuite, getTestCurrentResult, getSuiteCurrentResult, getSeleniumCode } = require("./controllers");
const { authMiddleware } = require("./middleware/auth");
const { validateCreateTest, validateCreateSuite } = require("./validator/validator");
const cors = require('cors');
const { client } = require("./db");
// const { Client } = require("redis-om");

const app = express();

app.use(cors());

const port = process.env.PORT;

app.use(express.json())

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  tracesSampleRate: 1.0
})

app.get("/", (req, res) => { 
  return res.send("OK");
});
app.post("/test", authMiddleware, validateCreateTest, runTest)
app.get("/selenium", authMiddleware, validateCreateTest, getSeleniumCode)
app.post("/tests/execute", authMiddleware, validateCreateTest, runTest)
app.get("/tests/executions/:execution_id", authMiddleware, getTestCurrentResult)
app.get("/suites/executions/:execution_id", authMiddleware, getSuiteCurrentResult)
app.post("/suite", authMiddleware, validateCreateSuite, runSuite)
app.post("/suites/execute", authMiddleware, validateCreateSuite, runSuite)

// const client = new Client()

app.listen(port, async () => {
  console.log("Server listening on port " + port);
  try {
    await client.connect()
    console.log("connected to redis database")
  } catch (error) {
    Sentry.captureException(error, "Starting redis database")
    console.log("Unable to connect to redis", error);
  }
})

// module.exports = { client }

