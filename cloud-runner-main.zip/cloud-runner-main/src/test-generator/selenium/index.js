const { getStepDelay, getTabToPlay, pretendAlertConfirmPromptDialogs, findFrame, findElement, scrollIntoViewIfNecessary, keysMapping, runPreconditionCheck, jsClick } = require("../../cloud-runner/cli-runner");
const VariableManager = require("../../cloud-runner/services/variableManagementService");
const { delay, isObjectEmpty, setFileInputs, dropFiles, simulateDragDrop, simulateMouseDragAndDrop, simulateNativeMouseDragAndDrop, patternMatch, setDateNatively } = require("../../cloud-runner/utils");
const { WebElement, Key, logging } = require("selenium-webdriver");
const fs = require("fs");
const path = require("path");
const FormData = require('form-data');
const { default: axios } = require('axios');


const screenshotsDir = path.join(__dirname, 'screenshots');

const pasteEventDispatcher = (value) => {
  function dispatchPaste(target, text) {
    const data = new DataTransfer()
    data.setData(
       // this could also be 'text/plain' -- it probably matters, but I'm not sure in which way
      'text/html',
      text
    )
  
    target.dispatchEvent(
      new ClipboardEvent('paste', {
        clipboardData: data,
  
        // need these for the event to reach Draft paste handler
        bubbles: true,
        cancelable: true
      })
    )
  }
  dispatchPaste(document.querySelector(".public-DraftEditor-content"), value)
}


class SeleniumTestConverter {
  constructor(testcase, browser, starting_url, hub_ip, variables, cli_run) {
    this.variableManager = new VariableManager();
    this.testcase = {
      ...testcase,
      starting_url: starting_url || testcase.starting_url
    };
    this.browser = browser || testcase.browser;
    if (hub_ip) {
      this.hubServer = `http://${hub_ip}:4444/wd/hub`
    }

    //populate global variables
    if (Array.isArray(variables)) {
      variables.forEach(variable => {
        this.variableManager.set({ [`${variable.name}`]: variable['value'] });
      });
    }

    //populate test variables
    if (Array.isArray(testcase.variables)) {
      testcase.variables.forEach(variable => {
        this.variableManager.set({ [`test.${variable.name}`]: variable['value'] });
      });
    }

    // populate file variables
    if (Array.isArray(testcase.fileVariables)) {
      testcase.fileVariables.forEach(variable => {
        this.variableManager.set({ [`file.${variable.name}`]: variable['value'] });
      });
    }
  }

  browser;
  variableManager;
  current_step;
  testcase;
  steps = [];
  hubServer = process.env.HUB_SERVER + "/wd/hub"
  screenshot = false;
  test = ""
  
  // hubServer = "http://localhost:4444/wd/hub"

  initialize = () => {
    this.test += `const runPreconditionCheck = ${runPreconditionCheck.toString()} '\n \n`;
    this.test += patternMatch.toString() + '\n \n';
    this.test += `const pasteEventDispatcher = ${pasteEventDispatcher.toString()} '\n \n'`;
    this.test += `const isObjectEmpty = ${isObjectEmpty.toString()} '\n \n'`;
    this.test += setDateNatively.toString() + '\n \n';
    this.test += setFileInputs.toString() + '\n \n';
    this.test += delay.toString() + '\n \n';
    this.test += simulateMouseDragAndDrop.toString() + '\n \n';
    this.test += simulateDragDrop.toString() + '\n \n';
    this.test += jsClick.toString() + '\n \n';
    this.test += getStepDelay.toString() + '\n \n';
    this.test += getTabToPlay.toString() + '\n \n';
    this.test += findElement.toString() + '\n \n';
    this.test += findElement.toString() + '\n \n';
    this.test += scrollIntoViewIfNecessary.toString() + '\n \n';
    this.test += keysMapping.toString() + '\n \n';
    this.test += pretendAlertConfirmPromptDialogs.toString() + '\n \n';
    this.test += dropFiles.toString() + '\n \n';
  }

  isGroupedStep = (step) => {
    return step.type === "group";
  }

  isEmptyGroup = (group) => {
    return group.steps && group.steps.length === 0;
  }

  isAStepInGroup = (step) => {
    return !!step.parentStepId
  }

  isLastStepInGroup = (step, group) => {
    return group.steps.findIndex(s => s.id === step.id) === (group.steps.length - 1)  
  }

  stepRunner = (step) => {
    let steptext = ''
    steptext += `// Step begin: ${step.title}, a ${step.type} \n `
    if (this.isGroupedStep(step)) {
      let group = (this.testcase.groups || []).find(group => group.id === step.id);
      let innerSteps = group.steps;
      innerSteps.forEach((_innerStep, index) => {
          innerSteps[index].parentStepId = group.id;
      });
      let currentStepIndex = this.steps.findIndex(s => s.id === step.id);
      
      this.steps.splice(currentStepIndex+1, 0, ...innerSteps);
      
      return;
    } else {
      try {

        if (step.element != undefined && step.element.hasOwnProperty('value') || (step.type == "assert" && step.hasOwnProperty('expectedValue'))){
          let valueWithVariablesReplaced = this.variableManager.replaceVariableWithValues(step.expectedValue || step.element.value);
          step.computedValue = valueWithVariablesReplaced;
        }

        steptext += `await delay(() => { }, getStepDelay(_${step.id})); \n`
        steptext += `let tabToPlay = await getTabToPlay(driver, _${step.id}); \n`
        steptext += `await driver.switchTo().window(tabToPlay); \n`
        steptext += `await driver.executeScript(pretendAlertConfirmPromptDialogs); \n`
        steptext += `let ${step.id}_target = null;`
        if (step.element && step.type != "visit") {
          steptext += `await driver.executeScript(pretendAlertConfirmPromptDialogs); \n`
          if (step.isTopFrame == false && step.framesStack != null) {
            for (let i = step.framesStack.length; i > 0; i--) {
              
              steptext += `let frame = await driver.wait(async (driver) => { \n
                let result = await findFrame(driver, step.framesStack[i - 1]); \n
                if (result instanceof WebElement) return result; \n
                return false; \n
                \n
              }, step.stepTimeout || 500, null); \n
              \n
              await driver.switchTo().frame(frame); \n`
            }
            steptext += `${step.id}_target = await driver.wait(async (driver) => { \n
                let result = await findElement(driver, _${step.id}, _${step.id}.mustBeVisible, _${step.id}.mustBeActionable); \n
                if (result instanceof WebElement) { return result }; \n
                return false; \n
            }, step.stepTimeout || 500, null); \n`
          } else {
            steptext += `${step.id}_target = await driver.wait(async (driver) => { \n
                console.log('Polling _${step}.title at 500ms interval'); \n
                \n
                let result = await findElement(driver, step, step.mustBeVisible, step.mustBeActionable); \n
                \n
                if (result instanceof WebElement) return result; \n
                console.log('Did not find _${step}.title'); \n
                return false; \n
                throw new Error(result.message) \n
                \n
              }, step.stepTimeout || 500, null) \n
            } \n
            if (_${step.id}.element && _${step.id}.element.scrollIntoView == true && ${step.id}_target != null && ${step.id}_target instanceof WebElement) { \n
              await driver.executeScript(scrollIntoViewIfNecessary, ${step.id}_target); \n
            }\n `
          }
        }
        if (step.type === "visit") {
          steptext += `await driver.get(starting_url || _${step.id}.page.url); \n`
        } else if (step.type === 'navigation') {
          steptext += `await driver.get(_${step.id}.page.url); \n`
        } else if (step.type === "file-input") {

          steptext += `await driver.executeScript(setFileInputs, ${step.id}_target, _${step.id}.files); \n`
          
        } else if (step.type === "file-drop") {
          
          steptext += `await driver.executeScript(dropFiles, ${step.id}_target, _${step.id}.files); \n`

        } else if (step.type === "click") {
          steptext += `try { \n
            await ${step.id}_target.click(); \n
          } catch (e) { \n
            if (e instanceof ElementClickInterceptedError || e instanceof ElementNotInteractableError || e instanceof InvalidArgumentError) { \n
              let eventModifiers = { \n
                  bubbles: true, \n
                  cancelable: true, \n
                  composed: true \n
              } \n
              \n
              await driver.executeScript(jsClick, ${step.id}_target, eventModifiers); \n
            } else { \n
              console.log("Error clicking on element", e) \n
              throw new Error('Unable to click on element'); \n
            }\n
          } \n`
        } else if (step.type === "change" || step.type === "editcontent" || step.type === "textInput") {
          if (step.element.tagName === "INPUT" || step.element.tagName === "TEXTAREA") {
            if (step.element.type === "date") {
              steptext += `await driver.executeScript(setDateNatively, ${step.id}_target, '${step.computedValue || step.element.value}'); \n`
            } else {
              steptext += `await ${step.id}_target.clear(); \n
              await ${step.id}_target.sendKeys('${step.computedValue || step.element.value}'); \n`
            }
            
          } 
          if (step.element.tagName === "SELECT") {
            steptext += `const ${step.id}_selectWrapper = new select.Select(${step.id}_target); \n
            \n
          // Select the option by value, text, or index \n
            ${step.id}_selectWrapper.selectByValue('${step.computedValue || step.element.value}');\n `
          }
          if (step.type === "editcontent" && step.element.classes.includes("ck-content")){
            steptext += `await driver.executeScript(\`arguments[0].ckeditorInstance.setData('${step.computedValue || step.element.value}')\`, ${step.id}_target); \n`
          } else if (step.type == "editcontent"){
            steptext += `if (patternMatch("DraftEditor", await ${step.id}_target.getAttribute("class")) { \n
              driver.executeScript(pasteEventDispatcher, '${step.computedValue || step.element.value}'); \n
            } else { \n
              await ${step.id}_target.clear(); \n
              await ${step.id}_target.sendKeys('${step.computedValue || step.element.value}'); \n
            } \n
            `
          }
        } else if (step.type === "scroll") {
          if (["window", "document"].includes(step.element.selector)) {
            steptext += `await driver.executeScript(\`window.scrollTo('${step.x}', '${step.y}')\`) \n`
          } else {
            steptext += `await driver.executeScript(\`scroll({ top: '${step.y}', left: '${step.x}', behaviour: 'smooth' })\`, ${step.id}_target); \n`
          }
        } else if (step.type === "keyup") {
          steptext += `let key = keysMapping[_${step.id}.element.key] || _${step.id}.element.key.toUpperCase(); \n
          await driver.actions().keyUp(Key[key]); \n `
        }  else if(step.type === "specialkey"){
          steptext += `let key = keysMapping[_${step.id}.element.key] || _${step.id}.element.key.toUpperCase(); \n
          await driver.actions().keyDown(Key[key]).keyUp(Key[key]).perform(); \n `
        } else if(["reload", "refresh"].includes(step.type)){
          steptext += `await driver.navigate().refresh(); \n `
        } else if (step.type == "assert") {
          steptext += `let ${step.id}_matchText = step.computedValue || step.expectedValue; \n
          let ${step.id}_pageTitle = await driver.getTitle(); \n
          let ${step.id}_pageUrl = await driver.getCurrentUrl(); \n
          let ${step.id}_elementText;`
          
          switch (step.subtype) {
            
            case 'page-title-is':
                steptext += `if (${step.id}_pageTitle !== ${step.id}_matchText) throw new AssertionFailed(\`Page title does not match. \n\tExpected: \${${step.id}_matchText}, \n\tFound: "\${${step.id}_pageTitle}"\`)`

                break;
                
            case 'page-title-contains':
            case 'page-title':
            case 'page-title-matches':
                steptext += `if (!patternMatch(${step.id}_matchText, ${step.id}_pageTitle)) throw new AssertionFailed(\`Page title does not match the specified regex. \n\tExpected: "\${${step.id}_matchText}", \n\tFound: "\${${step.id}_pageTitle}"\`)`
                break;
            
            case 'page-url-is':
                steptext += `if (${step.id}_pageUrl !== ${step.id}_matchText) throw new AssertionFailed(\`Page url does not match.\n\tExpected: "\${${step.id}_matchText}", \n\tFound: "\${${step.id}_pageUrl}"\`)`
                break;
            // case 'page-url-contains':
            //     if (!pageUrl.includes(matchText)) throw new AssertionFailed(`Page url does not contain the specified string. \n\tExpected: "${matchText}", \n\tFound: "${pageUrl}"`);
            //     break;
            case 'page-url':
            case 'page-url-contains':
            case 'page-url-matches':
                steptext += `if (!patternMatch(${step.id}_matchText, ${step.id}_pageUrl)) throw new AssertionFailed(\`Page url does not match the specified regex. \n\tExpected: "\${${step.id}_matchText}", \n\tFound: "\${${step.id}_pageUrl}"\`)`
                break;
            case 'page-text':
                steptext += `let ${step.id}_text = await driver.executeScript("return document.body.textContent"); \n
                if (!${step.id}_text.includes(${step.id}_matchText)) throw new AssertionFailed(\`Text not found in page. \n\tExpected text: "\${${step.id}_matchText}"\`)`
                break;
            case 'element-visible':
                steptext += `if(!${step.id}_target.isDisplayed()) throw new AssertionFailed(\`Element is expected to be visible\`) \n `;
                break;
            case 'element-not-visible':
                steptext += `if (${step.id}_target.isDisplayed()) throw new AssertionFailed(\`Element is expected to not be visible, but was found visible\`); \n `
                break;
            // case 'element-contains-text':
            //     elementText = await ${step.id}_target.getText()
            //     if (!elementText.includes(matchText)) throw new AssertionFailed(`Text does not match. \n\tExpected: "${matchText}", \n\tFound: "${elementText}"`);
            //     break;
            case 'element-contains-text':
            case 'element-text-matches':
                steptext += `${step.id}_elementText = await ${step.id}_target.getText() \n
                if (!patternMatch(${step.id}_matchText, ${step.id}_elementText)) throw new AssertionFailed(\`Element text does not match the specified regex. \n\tExpected: "\${${step.id}_matchText}", \n\tFound: "\${${step.id}_elementText}"\`);`
                break;
            case 'element-not-contains-text':
                steptext += `${step.id}_elementText = await ${step.id}_target.getText() \n
                if (${step.id}_elementText.includes(${step.id}_matchText)) throw new AssertionFailed(\`Text expected to not be found but was found. \n\t"\${${step.id}_matchText}" found in "\${${step.id}_elementText}"\`);`
                break;
            case 'element-enabled':
                steptext += `if ((await ${step.id}_target.isEnabled()) !== true) throw new AssertionFailed(\`Element is expected to be enabled, but was found disabled\`); \n `
                break;
            case 'element-disabled':
                steptext += `if ((await ${step.id}_target.isEnabled())) throw new AssertionFailed(\`Element is expected to be disabled, but was found enabled\`); \n `
                break;
            default:
                throw new Error("Unsupported assertion type");
          }
        } else if (step.type === "browser-alert"){
          if (step.dialogType === "prompt"){
            steptext += `await driver.executeScript(pretendAlertConfirmPromptDialogs, '${step.element.value}'); \n `
          }
        } else if (step.type === "draganddrop") {
                    
          if(step.isHTML5Drag){
            if(step.dragObjects.source != step.dragObjects.destination){
              steptext += `const ${step.id}_isDraggable = await ${step.id}_target.getAttribute('draggable') === 'true' || await ${step.id}_target.getAttribute('data-draggable') === 'true'; \n
              \n
              let ${step.id}_source; \n
              \n
              if (${step.id}_isDraggable) { \n
                ${step.id}_source = target; \n
              } else { \n
                // Find the closest ancestor that is draggable or has a specific attribute \n
                ${step.id}_source = await ${step.id}_target.findElement(By.xpath( \n
                  'ancestor::*[@draggable="true" or @data-draggable="true"]' \n
                )); \n
              } \n
              let dest = findElement(driver, step.dragObjects.destination) \n
              \n
              simulateDragDrop(driver, ${step.id}_source, dest); \n `
            }else{    
              steptext += `driver.executeScript(simulateNativeMouseDragAndDrop, target, step.dropLocation); \n `
                // simulateMouseDragAndDrop(driver, target, step.dropLocation)
            }
          }else{                        
              steptext += `driver.executeScript(simulateNativeMouseDragAndDrop, target, step.dropLocation); \n `                    
              // simulateMouseDragAndDrop(driver, target, step.dropLocation)
          }
        } else {
          console.log(`Unknown event type: ${step.type}`);
        }
      } catch (error) {
        console.log(`Step failed at: ${step.title}.\n\t Error: ${error.message} `);
        console.log("Step stack trace", error);
      }
    }

    return steptext;
  }

  captureScreenshot = async (step) => {
    const screenshotPath = path.join(screenshotsDir, `${step.id}_${new Date().getTime()}.png`);

    try {
      const img = await driver.takeScreenshot()
      fs.writeFileSync(screenshotPath, Buffer.from(img, 'base64'));

      const formData = new FormData();
      formData.append('file', fs.createReadStream(screenshotPath));
      formData.append('upload_preset', 'gtvrw8az');

      const uploadServiceUrl = process.env.CLOUDINARY_URL || 'https://api.cloudinary.com/v1_1/dyhmxy1no/image/upload';
      const { data } = await axios.post(uploadServiceUrl, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      step.result_screenshot = {
        imageDimensions: { width: data.width, height: data.height },
        imageData: data.secure_url,
      }
      this.updateStepResult(step);

      fs.unlinkSync(screenshotPath)
      console.log(`Screenshot uploaded: ${data.secure_url}`);
    } catch (error) {
      console.error('Upload error occurred', error);
    }
  };

  run = (retry = 0, screenshot = false) => {
    this.screenshot = screenshot;
    try {
      // console.log(`Starting window Id is: ${startingWindowId}`);
      this.steps = this.testcase.steps[0].meta;
      this.test += `const starting_url = ${this.testcase.starting_url}`

      for (let index = 0; index < this.steps.length; index++) {
        let step = this.steps[index];
        this.test += `const _${step.id} = ${step} \n`
        
        this.current_step = step;
        this.test += `const _${step.id}_condition = await runPreconditionCheck(driver, _${step.id}); \n`
        
        this.test += `if (condition.status) { \n `
          this.test += this.stepRunner(step);
        this.test += '}' 
        
        // (screenshot || this.failed) && await this.captureScreenshot(step);
      }
      return this.test;
    } catch(error){
     console.log(error)
    }
    
  }

}


module.exports = SeleniumTestConverter;
