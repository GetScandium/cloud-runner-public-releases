const { default: axios } = require("axios");
const Sentry = require("@sentry/node");
const { tryUntil } = require("../cloud-runner/utils");


class ApiService {
  constructor (apiToken, host) {
    this.url = host || process.env.BACKEND_SERVER;
    this.apiToken = apiToken;
    
    this.instantiateApi();
  }

  url;
  api;
  apiToken;

  instantiateApi = () => {
    this.api = axios.create({
      baseURL: this.url,
      headers: {
        "Content-Type": "application/json",
      }
    })
  }

  getTestData = async (project_id, id, folder_id) => {
  /// send request to legacy backend for testdata
    try {
      const res = await this.api.get(`/projects/${project_id}/test-cases/${id}?${folder_id ? `folder_id=${folder_id}` : ''}&api_token=${this.apiToken}`);

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed getting test data!")
      throw new Error(error);
    }
  }

  getTestsBySuite = async (project_id, suite_id) => {
    try {
      const res = await this.api.get(`/projects/${project_id}/test-cases?suite_id=${suite_id}&api_token=${this.apiToken}`);
      return res.data.data;
    } catch (error) {
      Sentry.captureException(error, "Failed to fetch suite's tests!")
      throw new Error(error);
    }
  }
  getGlobalVariables = async (project_id) => {
    try {
      const res = await this.api.get(`/projects/${project_id}/variables?api_token=${this.apiToken}`);

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed getting global variables!")
      throw new Error(error);
    }
  }

  getSuiteEnvironment = async (project_id) => {
    try {
      const res = await this.api.get(`/projects/${project_id}/environments?api_token=${this.apiToken}`)

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed getting suite environment!")
      throw new Error(error);
    }
  }

  getSuiteData = async (project_id, id) => {
  /// send request to legacy backend for testdata
    try {
      const res = await this.api.get(`/projects/${project_id}/suites/${id}?api_token=${this.apiToken}`);

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed getting suite data!")
      throw new Error(error);
    }
  }

  sendTestResult = async (result, { test_id, project_id }) => {
    /// send test result to legacy backend

    try {      
      const res = await this.api.post(`/projects/${project_id}/test-cases/${test_id}/runs?api_token=${this.apiToken}`, result)

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed sending test result!")
      console.log(error);
      // throw new Error(error);
    }
    
  }
  
  sendTestRunError = (error) => {
    console.log(error)
  }

  sendSuiteResult = async (result, project_id) => {
    /// send Suite result to legacy backend

    try {
      const res = await this.api.post(`/projects/${project_id}/execution-runs?api_token=${this.apiToken}`, result)

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed sending suite result!")
      // throw new Error(error);
      console.log(error);
    }
    
  }
  
  sendSuiteRunError = (error) => {
    console.log(error)
  }

  sendLogs = async ({ type, project_id, run_id, value }) => {
    /// send Suite result to legacy backend

    try {
      const res = await this.api.post(`/projects/${project_id}/test-runs/${run_id}/logs?api_token=${this.apiToken}`, {
        type, value
      })

      return res.data;
    } catch (error) {
      Sentry.captureException(error, "Failed sending suite result!")
      // throw new Error(error);
      console.log(error);
    }
    
  }
  
  sendSuiteRunError = (error) => {
    console.log(error)
  }

}

module.exports = ApiService;
