
class DataDriven {
  constructor (testcase) {
    this.data_source = testcase.data_source;
    delete testcase.data_source;
    this.testcase = testcase;
  }

  data_source;

  buildSuite = () => {
    const suite = {
      id: this.testcase.id,
      created_at: this.testcase.created_at,
      updated_at: this.testcase.updated_at,
      name: this.testcase.name,
      description: this.testcase.description,
      starting_url: this.testcase.starting_url,
      execution_type: "sequential",
      project_id: this.testcase.project_id,
      testcases: [],
      test_delay: 0,
      test_timeout: 0,
      test_retries: 0
    }

    this.data_source.forEach((data, index) => {
      const fileVariables = [];

      for (let key in data) {
        fileVariables.push({
          name: key,
          value: data[key],
        })
      }

      suite.testcases.push({
        ...this.testcase, fileVariables, data_source: null, testData: {
          data_params: data,
          current_index: index,
          total_loops: this.data_source.length
        }
      })
    })
    // const fileVariables = [];

    // const data = this.data_source[0]

    // for (let key in data) {
    //   fileVariables.push({
    //     name: key,
    //     value: data[key],
    //   })
    // }

    // suite.testcases.push({
    //   ...this.testcase, fileVariables, data_source: null,
    // })

    return suite;
  }
}

module.exports = DataDriven;
