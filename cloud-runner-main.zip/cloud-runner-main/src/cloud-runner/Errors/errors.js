class CustomError extends Error {
    constructor(message) {
        super(message);
        this.name = this.constructor.name;
    }
}

class ElementNotFoundError extends CustomError{
    constructor(message="Element not found"){
        super(message);
    }
}

class ElementFoundButNotVisible extends CustomError{
    constructor(message="Element was found, but it wasn't visible"){
        super(message)
    }
}

class ElementFoundButNotActionable extends CustomError{
    constructor(message="Element was found, visible, but it wasn't actionable"){
        super(message);
    }
}

class AssertionFailed extends CustomError{
    constructor(message="Assertion failed"){
        super(message);
    }
}

module.exports = {
    ElementNotFoundError,
    ElementFoundButNotVisible,
    ElementFoundButNotActionable,
    AssertionFailed
}