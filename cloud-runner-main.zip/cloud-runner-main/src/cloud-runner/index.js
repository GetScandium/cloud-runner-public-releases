const TestRunner = require("./testRunner");

let testcase = require("./sample-tests/file-upload-test.json");

const browsers = ["firefox"]

Promise.all(browsers.map(async browser => {
  if (Array.isArray(testcase.data_source)) {
    const fileVariables = [];

    const data = testcase.data_source[0]

    for (let key in data) {
      fileVariables.push({
        name: key,
        value: data[key],
      })
    }

    testcase = {
      ...testcase, fileVariables, data_source: null,
    }
  }

  const testRunner = new TestRunner(testcase, browser);

  await testRunner.initializeDriver();

  await testRunner.run();
}))
