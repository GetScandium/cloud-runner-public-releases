const select = require('selenium-webdriver/lib/select');
const { driverBuilder, getStepDelay, getTabToPlay, pretendAlertConfirmPromptDialogs, findFrame, findElement, scrollIntoViewIfNecessary, keysMapping, runPreconditionCheck, jsClick } = require("./cli-runner");
const VariableManager = require("./services/variableManagementService");
const { delay, isObjectEmpty, setFileInputs, dropFiles, simulateDragDrop, simulateMouseDragAndDrop, simulateNativeMouseDragAndDrop, patternMatch, setDateNatively } = require("./utils");
const { AssertionFailed, ElementNotFoundError } = require("./Errors/errors");
const { WebElement, Key, logging } = require("selenium-webdriver");
const LogInspector = require('selenium-webdriver/bidi/logInspector');
const fs = require("fs");
const path = require("path");
const FormData = require('form-data');
const { default: axios } = require('axios');
const { ElementClickInterceptedError, ElementNotInteractableError, InvalidArgumentError } = require('selenium-webdriver/lib/error');
const { Repository, EntityId } = require('redis-om');
const runSchema = require('../server/db/Runs');
const { client } = require('../server/db');
const nanoid = require('nanoid');
const Sentry = require("@sentry/node");
const HTML_BOOLEAN_ATTRIBUTES = [
  "allowfullscreen", "async", "autofocus", "autoplay", "checked", "controls", "default", "defer",
  "disabled", "formnovalidate", "inert", "ismap", "itemscope", "loop", "multiple",
  "muted", "nomodule", "novalidate", "open", "playsinline", "readonly", "required",
  "reversed", "selected"
]
const screenshotsDir = path.join(__dirname, 'screenshots');

const pasteEventDispatcher = (value) => {
  function dispatchPaste(target, text) {
    const data = new DataTransfer()
    data.setData(
       // this could also be 'text/plain' -- it probably matters, but I'm not sure in which way
      'text/html',
      text
    )
  
    target.dispatchEvent(
      new ClipboardEvent('paste', {
        clipboardData: data,
  
        // need these for the event to reach Draft paste handler
        bubbles: true,
        cancelable: true
      })
    )
  }
  dispatchPaste(document.querySelector(".public-DraftEditor-content"), value)
}


class TestRunner {
  constructor(testcase, browser, starting_url, hub_url, variables, cli_run) {
    this.variableManager = new VariableManager();
    this.testcase = {
      ...testcase,
      starting_url: starting_url || testcase.starting_url
    };
    this.browser = browser || testcase.browser;
    
    if (hub_url) {
      this.hubServer = hub_url;
    }

    //populate global variables
    if (Array.isArray(variables)) {
      variables.forEach(variable => {
        this.variableManager.set({ [`${variable.name}`]: variable['value'] });
      });
    }

    //populate test variables
    if (Array.isArray(testcase.variables)) {
      testcase.variables.forEach(variable => {
        this.variableManager.set({ [`test.${variable.name}`]: variable['value'] });
      });
    }

    // populate file variables
    if (Array.isArray(testcase.fileVariables)) {
      testcase.fileVariables.forEach(variable => {
        this.variableManager.set({ [`file.${variable.name}`]: variable['value'] });
      });
    }

    if (!cli_run) {
      this.runRepo = new Repository(runSchema, client);
      this.cli_run = false;
    } else {
      this.cli_run = cli_run;
    }
  }

  driver;
  browser;
  variableManager;
  logger;
  current_step;
  testResults;
  testcase;
  steps = [];
  running_test_status;
  failed = false;
  error = "";
  hubServer = process.env.HUB_SERVER + "/wd/hub"
  runRepo;
  entity = "";
  results = []
  errors = []
  screenshot = false;
  cli_run = false;
  console_log;
  
  // hubServer = "http://localhost:4444/wd/hub"

  running_states = {
    PENDING: "pending",
    RUNNING: "running",
    ABORTED: "aborted",
    COMPLETED: "completed",
    PAUSED: "paused",
    STOPPED: "stopped",
    QUEUED: "queued"
  }

  initializeDriver = async () => {
    console.log("=====================================")
    console.log("Hub server is address", this.hubServer)
    console.log("=====================================")
    try {
      this.driver = await driverBuilder({
        browser: this.browser || this.testcase.browser, 
        hubServer: this.hubServer,
        width: this.testcase.width,
        height: this.testcase.height,
      });
  
      let startingWindowId = await this.driver.getWindowHandle();
  
      return await this.initializeTestResult(startingWindowId);
    } catch (error) {
      console.log(error);
      if (error?.name === "SessionNotCreatedError" || error?.name === "NoSuchSessionError") {
        Sentry.captureException(this.errors[this.errors.length - 1], "Session fail error!")
        await this.initializeDriver()
      }
    }
  }

  initializeTestResult = async (browser_session_id) => {
    const capabilities = await this.driver.getCapabilities()
    this.testResults = {
      id: nanoid(),
      starting_url: this.testcase.starting_url,
      source: "remote",
      browser: capabilities.getBrowserName(),
      browser_version: capabilities.getBrowserVersion(),
      operating_system: capabilities.getPlatform(),
      operating_system_version: "",
      is_mobile: false,
      duration: 0,
      started_at: Date.now(),
      finished_at: 0,
      status: null,
      running_status: "pending", //completed
      steps: [],
      test_id: this.testcase.id,
      name: this.testcase.name,
      testData: this.testcase.testData,
    }

    if (!this.cli_run) {
      const data = await this.runRepo.save(this.testResults.id, { ...this.testResults, browser_session_id, testData: JSON.stringify(this.testResults.testData) });

      this.entity = data;
    }

    this.running_test_status = this.running_states.RUNNING;

    return this.entity;
  }

  isGroupedStep = (step) => {
    return step.type === "group";
  }

  isEmptyGroup = (group) => {
    return group.steps && group.steps.length === 0;
  }

  isAStepInGroup = (step) => {
    return !!step.parentStepId
  }

  isLastStepInGroup = (step, group) => {
    return group.steps.findIndex(s => s.id === step.id) === (group.steps.length - 1)  
  }

  getGroup = (groupId) => {
    return this.testcase.groups.find(g => g.id === groupId);
  }

  updateRedisResult = async (result) => {
    if (!this.cli_run) {
      const data = await this.runRepo.save({
        ...this.entity, steps: result.steps.map(s => JSON.stringify(s))
      })
  
      this.entity = data;
    }
  }

  initializeStepResult = (step) => {
    let result = {
      id: step.id,
      start_timestamp: Date.now(),
      parentStepId: step.parentStepId,
      onError: step.onError,
      error: step.error,
      step_id: step.id,
      title: step.title,
      type: step.type,
      running_status: step.running_status,
      result_screenshot: {
        imageDimensions: null,
        imageData: ""
      }
    }
    this.testResults.steps.push(result);

    !this.cli_run && this.updateRedisResult(this.testResults);
  }

  updateStepResult = (step) => {
    let existingStepResultIndex = this.testResults.steps.findIndex(s => s.id === step.id);
    let updatedResult;
    if (existingStepResultIndex > -1) {
      const existingStepResult = this.testResults.steps[existingStepResultIndex];
      updatedResult = {
        id: step.id,
        end_timestamp: step.end_timestamp ?? existingStepResult.end_timestamp,
        time_taken: step.time_taken ?? existingStepResult.time_taken,
        parentStepId: step.parentStepId ?? existingStepResult.parentStepId,
        status: step.status ?? existingStepResult.status,
        running_status: step.running_status ?? existingStepResult.running_status,
        result_screenshot: step.result_screenshot ?? existingStepResult.result_screenshot,
        onError: step.onError ?? existingStepResult.onError,
        error: step.error ?? existingStepResult.error,
        warnings: step.warnings ?? existingStepResult.warnings,
        conditionResult: step.conditionResult ?? existingStepResult.conditionResult
      }
      
      updatedResult = {...existingStepResult, ...updatedResult}
      this.testResults.steps[existingStepResultIndex] = updatedResult;

      !this.cli_run && this.updateRedisResult(this.testResults);
    } else {
      throw new Error("Can not update an uninitialized step result")
    }

    return updatedResult
  }

  getStepResult = (stepId) => {
    return this.testResults.steps.find(e => e.id === stepId)
  }

  stepDone = async (step, status = "success") => {
      // process step result, end its playback time, save result and report to scandium dashboard
      if (this.running_test_status !== "running"){
        //reject result received after playback has ended
        console.log("Result received after playback has ended")
        // return;
      }
      let stepResult = this.getStepResult(step.id);
      
      step.end_timestamp = Date.now();
      step.time_taken = Date.now() - stepResult.start_timestamp;
      step.running_status = this.running_states.COMPLETED;
      step.status = status

      if (this.isAStepInGroup(step)){
        let groupResult = this.getStepResult(step.parentStepId);
        
        if (this.isLastStepInGroup(step, this.getGroup(groupResult.id))){
          groupResult.running_status = this.running_states.COMPLETED;
          groupResult.status = this.testResults.steps.filter(step => step.parentStepId === groupResult.id).findIndex(s => s.status === "error") === -1 ? "success": "error";
          groupResult.end_timestamp = Date.now();
          groupResult.time_taken = Date.now() - groupResult.start_timestamp;
          this.updateStepResult(groupResult);
        }
      }
      
      this.updateStepResult(step)

    if (step.status === "error" && step.onError === "fail"){
      // decide if to run next step or not
      // depending on the stopOnError settings of the current event
      // this.last_play_tab != null ? chrome.tabs.sendMessage(this.last_play_tab.id, { cmd: "show-snackbar", message: `An error has occured: <strong>${step.error}.</strong> Check Scandium dashboard for details` }) : "";
      delay(() => {
        Promise.all(apiPromises).then(() => {
            this.stopPlayer({ reason: step.error, error: step.error });
            apiPromises = [];
        }).catch((err) => {
            this.stopPlayer({ reason: step.error, error: step.error });
            apiPromises = [];
        })
      }, 2500)
      return;
    }

    if (step.variable_assignment != undefined && step.variable_assignment.name != undefined && !isObjectEmpty(step.target)) {
                                    
      let varAssignment = {
        [`step.${step.variable_assignment.name}`]: (['INPUT', 'SELECT', 'TEXTAREA'].includes(step.element.tagName) ? await step.target.getAttribute("value") : await step.target.getText())
      }
      
      this.variableManager.set(varAssignment);
    }
  }

  stepFail = (step, error) => {
    // process step result, end its playback time, save result and report to scandium dashboard
    if (this.running_test_status !== "running"){
      //reject result received after playback has ended
      console.log("Result received after playback has ended")
      // return;
    }
    let stepResult = this.getStepResult(step.id);
    
    step.end_timestamp = Date.now();
    step.time_taken = Date.now() - stepResult.start_timestamp;
    step.running_status = this.running_states.COMPLETED;
    step.error = error.message;
    this.error = error.message;
    step.error_type = error.stack;
    step.status = step.onError === "ignore" ? "ignored" : "error";
    
    this.updateStepResult(step)

    if (step.onError === "fail") {
      this.failed = true;
    }

    return;
  }


  onTestPlaybackComplete(options={reason: undefined, running_test_status: undefined}, e){
    if (this.running_test_status !== this.running_states.RUNNING){
        console.log(`${this.running_test_status}: prompt received after test playback is completed`, options, e);
        return;
    }

    this.running_test_status = options.running_test_status ?? this.running_states.COMPLETED;
    let currentTestResult = {
      status: (this.testResults.steps.findIndex(step => step.status === "error") !== -1) ? "error" : "success",
      finished_at: Date.now(),
      duration: Date.now() - this.testResults.started_at,
      running_status: this.running_test_status,// this.running_states.COMPLETED,
      reason: (this.testResults.steps.findIndex(step => step.status === "error") !== -1) ? options.reason : null,
      summary: {
        total: this.testResults.steps.length,
        passed: (this.testResults.steps.filter(step => step.status === "success").length),
        failed: (this.testResults.steps.filter(step => step.status === "error").length),
        skipped: (this.testResults.steps.filter(step => step.status === "skipped").length),
        ignored: (this.testResults.steps.filter(step => step.status === "ignored").length),
      },
      test_runs: this.testResults.steps.map(step => ({
        step_id: step.id,
        status: step.status,
        time_taken: step.time_taken,
        result_screenshot: step.result_screenshot,
        title: step.title,
        error: step.error,
        end_timestamp: step.end_timestamp,
        start_timestamp: step.start_timestamp,
      })),
    }
    
    this.testResults = {
      ...this.testResults,
      ...currentTestResult,
    }
    
    this.playing_status = this.running_states.COMPLETED;

    !this.cli_run && this.runRepo.expire(this.entity[EntityId], 3 * 60);
 
    return;
  }

  stepRunner = async (step, retry = 1) => {
    console.log(`Step begin: ${step.title}, a ${step.type}`);

    if (this.isGroupedStep(step)) {
      let group = (this.testcase.groups || []).find(group => group.id === step.id);
      let innerSteps = group.steps;
      innerSteps.forEach((_innerStep, index) => {
          innerSteps[index].parentStepId = group.id;
      });
      let currentStepIndex = this.steps.findIndex(s => s.id === step.id);
      
      this.steps.splice(currentStepIndex+1, 0, ...innerSteps);
      await this.stepDone(step);
      
      return;
    } else {
      try {

        if (step.element != undefined && step.element.hasOwnProperty('value') || (step.type == "assert" && step.hasOwnProperty('expectedValue'))){
          let valueWithVariablesReplaced = this.variableManager.replaceVariableWithValues(step.expectedValue || step.element.value);
          step.computedValue = valueWithVariablesReplaced;
        }

        await delay(() => { }, getStepDelay(step));
        let tabToPlay = await getTabToPlay(this.driver, step);
        await this.driver.switchTo().window(tabToPlay);
        await this.driver.executeScript(pretendAlertConfirmPromptDialogs);
        let target = null;
        if (step.element && step.type != "visit") {
          try {
            await this.driver.executeScript(pretendAlertConfirmPromptDialogs);
            console.log(`Will be polling ${step.title} for ${step.stepTimeout}`);
            if (step.isTopFrame == false && step.framesStack != null) {
              for (let i = step.framesStack.length; i > 0; i--) {
                
                let frame = await this.driver.wait(async (driver) => {
                  let result = await findFrame(driver, step.framesStack[i - 1]);
                  if (result instanceof WebElement) return result;
                  return false;
                    
                }, step.stepTimeout || 500, null);
  
                await this.driver.switchTo().frame(frame);
              }
              target = await this.driver.wait(async (driver) => {
                  let result = await findElement(this.driver, step, step.mustBeVisible, step.mustBeActionable);
                  if (result instanceof WebElement) { return result };
                  return false;
                  // throw new Error(result.message)
              }, step.stepTimeout || 500, null);
            } else {
              target = await this.driver.wait(async (driver) => {
                console.log(`Polling ${step.title} at 500ms interval`);

                let result = await findElement(driver, step, step.mustBeVisible, step.mustBeActionable);

                if (result instanceof WebElement) return result;
                console.log(`Did not find ${step.title}`);
                return false;
                throw new Error(result.message)

              }, step.stepTimeout || 500, null)
            }
            if (step.element && step.element.scrollIntoView == true && target != null && target instanceof WebElement) {
              await this.driver.executeScript(scrollIntoViewIfNecessary, target);
            }
          } catch (error) {
            console.log("An error from locating", error);
            throw new ElementNotFoundError();
            
            //   continue;
          }
        }
        if (step.type === "visit") {
          await this.driver.get(this.testcase.starting_url || step.page.url);
        } else if (step.type === 'navigation') {
          await this.driver.get(step.page.url);
        } else if (step.type === "file-input") {

          await this.driver.executeScript(setFileInputs, target, step.files);
          
        } else if (step.type === "file-drop") {
          
          await this.driver.executeScript(dropFiles, target, step.files);

        } else if (step.type === "click") {
          try {
            await target.click();
          } catch (e) {
            if (e instanceof ElementClickInterceptedError || e instanceof ElementNotInteractableError || e instanceof InvalidArgumentError) {
              let eventModifiers = {
                  bubbles: true,
                  cancelable: true,
                  composed: true
              }

              await this.driver.executeScript(jsClick, target, eventModifiers);
            } else {
              console.log("Error clicking on element", e)
              throw new Error(`Unable to click on element`);
            }
          }
        } else if (step.type === "change" || step.type === "editcontent" || step.type === "textInput") {
          if (step.element.tagName === "INPUT" || step.element.tagName === "TEXTAREA") {
            if (step.element.type === "date") {
              await this.driver.executeScript(setDateNatively, target, step.computedValue || step.element.value);
            } else {
              await target.clear();
              await target.sendKeys(step.computedValue || step.element.value);
            }
            
          } 
          if (step.element.tagName === "SELECT") {
            const selectWrapper = new select.Select(target);

          // Select the option by value, text, or index
            selectWrapper.selectByValue(step.computedValue || step.element.value); 
          }
          if (step.type === "editcontent" && step.element.classes.includes("ck-content")){
            await this.driver.executeScript(`arguments[0].ckeditorInstance.setData(\`${step.computedValue || step.element.value}\`)`, target);
          } else if (step.type === "editcontent" && patternMatch("DraftEditor", await target.getAttribute("class"))) {
            this.driver.executeScript(pasteEventDispatcher, step.computedValue || step.element.value);
          } else if (step.type == "editcontent"){
            await target.clear();
            await target.sendKeys(step.computedValue || step.element.value);
          }
        } else if (step.type === "scroll") {
          if (["window", "document"].includes(step.element.selector)) {
            await this.driver.executeScript(`window.scrollTo(${step.x}, ${step.y})`)
          } else {
            await this.driver.executeScript(`scroll({ top: ${step.y}, left: ${step.x}, behaviour: 'smooth' })`, target);
          }
        } else if (step.type === "keyup") {
          let key = keysMapping[step.element.key] || step.element.key.toUpperCase();
          await this.driver.actions().keyUp(Key[key]);
        }  else if(step.type === "specialkey"){
          let key = keysMapping[step.element.key] || step.element.key.toUpperCase();
          await this.driver.actions().keyDown(Key[key]).keyUp(Key[key]).perform();
        }
        else if(["reload", "refresh"].includes(step.type)){
          await this.driver.navigate().refresh();
        } else if (step.type == "assert") {
          let matchText = step.computedValue || step.expectedValue;
          let pageTitle = await this.driver.getTitle();
          let pageUrl = await this.driver.getCurrentUrl();
          let elementText;
          // let elementText = await target.getText()
          switch (step.subtype) {
            
            case 'page-title-is':
                if (pageTitle !== matchText) throw new AssertionFailed(`Page title does not match. \n\tExpected: "${matchText}", \n\tFound: "${pageTitle}"`)

                break;
            // case 'page-title-contains':
            //     if (!pageTitle.includes(matchText)) throw new AssertionFailed(`Page title does not contain the specified string. \n\tExpected: "${matchText}", \n\tFound: "${pageTitle}"`);
            //     break;
            case 'page-title-contains':
            case 'page-title':
            case 'page-title-matches':
                if (!patternMatch(matchText, pageTitle)) throw new AssertionFailed(`Page title does not match the specified regex. \n\tExpected: "${matchText}", \n\tFound: "${pageTitle}"`)
                break;
            
            case 'page-url-is':
                if (pageUrl !== matchText) throw new AssertionFailed(`Page url does not match.\n\tExpected: "${matchText}", \n\tFound: "${pageUrl}"`)
                break;
            // case 'page-url-contains':
            //     if (!pageUrl.includes(matchText)) throw new AssertionFailed(`Page url does not contain the specified string. \n\tExpected: "${matchText}", \n\tFound: "${pageUrl}"`);
            //     break;
            case 'page-url':
            case 'page-url-contains':
            case 'page-url-matches':
                if (!patternMatch(matchText, pageUrl)) throw new AssertionFailed(`Page url does not match the specified regex. \n\tExpected: "${matchText}", \n\tFound: "${pageUrl}"`)
                break;
            case 'page-text':
                let text = await this.driver.executeScript("return document.body.textContent");
                if (!text.includes(matchText)) throw new AssertionFailed(`Text not found in page. \n\tExpected text: "${matchText}"`)
                break;
            case 'element-visible':
                if(!target.isDisplayed()) throw new AssertionFailed(`Element is expected to be visible`);
                break;
            case 'element-not-visible':
                if (target.isDisplayed()) throw new AssertionFailed(`Element is expected to not be visible, but was found visible`);
                break;
            // case 'element-contains-text':
            //     elementText = await target.getText()
            //     if (!elementText.includes(matchText)) throw new AssertionFailed(`Text does not match. \n\tExpected: "${matchText}", \n\tFound: "${elementText}"`);
            //     break;
            case 'element-contains-text':
            case 'element-text-matches':
                elementText = await target.getText()
                if (!patternMatch(matchText, elementText)) throw new AssertionFailed(`Element text does not match the specified regex. \n\tExpected: "${matchText}", \n\tFound: "${elementText}"`);
                break;
            case 'element-not-contains-text':
                elementText = await target.getText()
                if (elementText.includes(matchText)) throw new AssertionFailed(`Text expected to not be found but was found. \n\t"${matchText}" found in "${elementText}"`);
                break;
            case 'element-enabled':
                if ((await target.isEnabled()) !== true) throw new AssertionFailed(`Element is expected to be enabled, but was found disabled`);
                break;
            case 'element-disabled':
                if ((await target.isEnabled())) throw new AssertionFailed(`Element is expected to be disabled, but was found enabled`);
                break;
            case 'element-html-property':
              if ((await target.getAttribute(step.expectedPropertyName)) == null) throw new AssertionFailed(`Element is expected to have HTML property "${step.expectedPropertyName}". Property not found`);
              if (HTML_BOOLEAN_ATTRIBUTES.includes(step.expectedPropertyName)){
                break;
              }
              let attribute = await target.getAttribute(step.expectedPropertyName);
              if (!patternMatch(matchText, attribute)) {
                throw new AssertionFailed(`Element's HTML "${step.expectedPropertyName}" property is expected to have value "${matchText}". But "${attribute}" was found`);
              }
              break;
            case 'element-css-property':
              let cssAttribute = await target.getCssValue(step.expectedPropertyName);
              if (!patternMatch(matchText, cssAttribute)){
                throw new AssertionFailed(`Element's CSS "${step.expectedPropertyName}" property is expected to have value "${matchText}". But "${cssAttribute}" was found`);
              }
              break;
            default:
                throw new Error("Unsupported assertion type");
                break;
          }
        }
        else if (step.type === "browser-alert"){
          if (step.dialogType === "prompt"){
            await this.driver.executeScript(pretendAlertConfirmPromptDialogs, step.element.value);
          }
        } else if (step.type === "draganddrop") {
                    
        if(step.isHTML5Drag){
            if(step.dragObjects.source != step.dragObjects.destination){
              const isDraggable = await target.getAttribute('draggable') === 'true' || await target.getAttribute('data-draggable') === 'true';

              let source;
          
              if (isDraggable) {
                source = target;
              } else {
                // Find the closest ancestor that is draggable or has a specific attribute
                source = await target.findElement(By.xpath(
                  'ancestor::*[@draggable="true" or @data-draggable="true"]'
                ));
              }
              let dest = findElement(this.driver, step.dragObjects.destination)
                
              simulateDragDrop(this.driver, source, dest);
            }else{    
              this.driver.executeScript(simulateNativeMouseDragAndDrop, target, step.dropLocation);                        
                // simulateMouseDragAndDrop(this.driver, target, step.dropLocation)
            }
        }else{                        
              this.driver.executeScript(simulateNativeMouseDragAndDrop, target, step.dropLocation);                        
              // simulateMouseDragAndDrop(this.driver, target, step.dropLocation)
        }
      } else {
            console.log(`Unknown event type: ${step.type}`);
        }

        await this.stepDone({ ...step, target });
      } catch (error) {
        console.log(`Step failed at: ${step.title}.\n\t Error: ${error.message} `);
        console.log("Step stack trace", error);
        if (error?.name === "StaleElementReferenceError" && retry > 0) {
          console.log("Retrying stale error:")
          return await this.stepRunner(step, 0);
        }
        this.stepFail(step, error);
      }
    }
  }

  captureScreenshot = async (step) => {
    const screenshotPath = path.join(screenshotsDir, `${step.id}_${new Date().getTime()}.png`);

    try {
      const img = await this.driver.takeScreenshot()
      fs.writeFileSync(screenshotPath, Buffer.from(img, 'base64'));

      const formData = new FormData();
      formData.append('file', fs.createReadStream(screenshotPath));
      formData.append('upload_preset', 'gtvrw8az');

      const uploadServiceUrl = process.env.CLOUDINARY_URL || 'https://api.cloudinary.com/v1_1/dyhmxy1no/image/upload';
      const { data } = await axios.post(uploadServiceUrl, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      step.result_screenshot = {
        imageDimensions: { width: data.width, height: data.height },
        imageData: data.secure_url,
      }
      this.updateStepResult(step);

      fs.unlinkSync(screenshotPath)
      console.log(`Screenshot uploaded: ${data.secure_url}`);
    } catch (error) {
      console.error('Upload error occurred', error);
    }
  };

  run = async (retry = 0, screenshot = false) => {
    this.screenshot = screenshot;
    try {
      // console.log(`Starting window Id is: ${startingWindowId}`);
      this.steps = this.testcase.steps[0].meta;

      for (let index = 0; index < this.steps.length; index++) {
        let step = this.steps[index];
        
        this.current_step = step;
        this.initializeStepResult(step);
        const condition = await runPreconditionCheck(this.driver, step)
        
        if (condition.status) {
          await this.stepRunner(step);
        } else {
          step.conditionResult = condition.reason
          // step.conditionReson = condition.reason
          await this.stepDone(step, "skipped")
        }
        
        (screenshot || this.failed) && await this.captureScreenshot(step);
        if (this.failed === true) break;
      }

      this.onTestPlaybackComplete({
        reason: this.failed ? this.error : "Test completed"
      })
    } catch(error){
      this.errors.push(error);
    } finally {
      this.results.push(this.testResults);

      this.console_log = await this.driver.manage().logs().get("browser").catch((err) => console.log(err))

      await this.driver.quit()
      
      if (retry > 0 && this.testResults.status === "error") {
        await this.initializeDriver()
        return await this.run(retry - 1, this.screenshot);
      } else {
        return { result: this.testResults, results: this.results, errors: this.errors, logs: { console: this.console_log } }
      }
    }
    
  }

}

module.exports = TestRunner;
