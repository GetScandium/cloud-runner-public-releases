class StepItem{
    id;
    type;
    timestamp;
    windowHeight;
    windowWidth;
    title;
    element = new StepElement();
    tabDetails = new TabDetails();
    page = new StepPage();
    altKey;
    ctrlKey;
    shiftKey;
    metaKey;
    pageX;
    pageY;
    eventTime;
    onError;
    stepTimeout;
    preStepDelay;
    mustBeVisible;
    mustBeActionable;
    isTopFrame;
    screenshot;
    x;
    y;
    framesStack = new StepFramesStack();
}

class StepElement{
    selector = "";
    tagName = "";
    classes = [];
    id = "";
    scrollIntoView = true;
    xpathLocator = "";
    customSelector = null;
    pageX = 0;
    pageY = 0;
}

class TabDetails{
    position;
    id;
}

class StepPage{
    url;
    title;
}

class StepFramesStack{
    selector;
    xpathLocator;
    name;
    id;
    tagName;
    index;
    src;
    within_frame;
    page = new StepPage();
}