const { Repository } = require("redis-om");
const TestRunner = require("./testRunner");
const nanoid = require("nanoid");
const suitesSchema = require("../server/db/Suites");
const { client } = require("../server/db");

class SuiteRunner {
  constructor (suite, env, run_type = "parallel", cli_run = false, hub_url) {
    this.suite = suite;
    this.env = env;
    this.run_type = run_type;
    this.cli_run = cli_run;
    if (!cli_run) {
      this.suiteRepo = new Repository(suitesSchema, client)
    }
    if (hub_url) {
      this.hubServer = hub_url;
    }
  }
  suite;
  env;
  apiService;
  suiteResult = {};
  test_fail_count = 0
  suiteRepo;
  run_type;
  cli_run;
  hubServer = process.env.HUB_SERVER + "/wd/hub"


  async initializeSuiteResult(){
    this.suiteResult = {
        id: nanoid(),
        source: "remote",
        browser: this.env.browser || this.suite.browser,
        browser_version: "",
        operating_system: this.env.operating_system || "linux",
        operating_system_version: "ubuntu",
        is_mobile: false,
        duration: 0,
        started_at: Date.now(),
        finished_at: 0,
        type: "suite",
        type_id: this.suite.id,
        name: this.suite.name,
        status: null,
        running_status: "running", //completed
        results: []
    }

    if (!this.cli_run) {
      const data = await this.suiteRepo.save(this.suiteResult.id, this.suiteResult);

      this.entity = data;
    }

    return this.entity;
  }

  addTestResult = async (result) => {
    this.suiteResult.results.push(result);
    
    if (!this.cli_run) {
      this.entity = await this.suiteRepo.save({ ...this.suiteResult, results: this.suiteResult.results.map(r => JSON.stringify(r)) });
    }
  }

  completeSuite = () => {
    const finished_at = Date.now()
    this.suiteResult = {
      ...this.suiteResult,
      finished_at,
      duration: finished_at - this.suiteResult.started_at,
      running_status: "completed",
      status: (this.suiteResult.results.findIndex(test => test.status === "error") !== -1) ? "error" : "success",
      browser_version: this.suiteResult.results[0].browser_version,
      summary: {
          total: this.suiteResult.results.length,
          passed: this.suiteResult.results.filter(test => test.status === "success").length,
          failed: this.suiteResult.results.filter(test => test.status === "error").length,
      }
    }

    !this.cli_run && this.suiteRepo.save({ ...this.suiteResult, results: this.suiteResult.results.map(r => JSON.stringify(r)), summary: JSON.stringify(this.suiteResult.summary) }).then(r => {
      !this.cli_run && this.suiteRepo.expire(this.suiteResult.id, 3 * 60);
    })
    
  }

  run = async (retry = 0, screenshot = false) => {

    if (this.suite?.testcases?.length) {
      if (this.run_type === "parallel") {
        await Promise.all(this.suite.testcases.map(async testcase => {
          try {  
            const testRunner = new TestRunner(testcase, this.env.browser, null, this.hubServer, null, this.cli_run);
    
            await testRunner.initializeDriver()
    
            const {result} = await testRunner.run(retry, screenshot)
    
            delete result.steps;

            this.addTestResult(result);
          } catch (error) {
            this.test_fail_count += 1
            this.addTestResult(error);
          }
        }))
      } else {
        for (let i = 0; i < this.suite.testcases.length; i++) {
          const testcase = this.suite.testcases[i];
          
          try {  
            const testRunner = new TestRunner(testcase, this.env.browser, null, this.hubServer, null, this.cli_run);
    
            await testRunner.initializeDriver()
    
            const {result} = await testRunner.run()
    
            delete result.steps;

            this.addTestResult(result);
          } catch (error) {
            this.test_fail_count += 1
            this.addTestResult(error);
          }
        }
      }
      
  
      this.completeSuite();
  
      return { result: this.suiteResult }
    }
    
  }
}

module.exports = SuiteRunner;
