# Deployment Requirement

### For Server Deployment
**There are two options for the installation of the required selenium grid.**
_both options are explained below_

1. With Manual Docker Installation
   - install selenium grid using docker [use this link to install each requirements](https://github.com/SeleniumHQ/docker-selenium#hub-and-nodes)
   - then start the server with `npm run start-server`
2. With docker-compose
   - you just run `docker-compose up --build` and it will run all needed docker containers before starting the server
3. You can as well use a standalone browser driver
   - in this deployment method only a single browser will be available for running tests
   - you can choose the need browser container from [here](https://github.com/SeleniumHQ/docker-selenium#standalone)
   - then start the server with `npm run start-server`

> Ensure all instance of the selenium grid or the standalone (as the case may be) is running on port 4444 so that the node app can communicate with it.
