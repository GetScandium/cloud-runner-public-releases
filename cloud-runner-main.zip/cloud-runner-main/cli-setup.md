# Setting up Scandium CLI Tool

1. clone repo
2. install dependencies (npm install)
3. start up a selenium hub grid
4. install cli tool globally (npm i -g)

`and you are good to go!!!!!`

## Sample Use Case:

- To run testcase:
  scandium-cli test -i {test_id} -p {project_id} -k {api key} -b {browser} -s {screeeshot true or false} -r {retry} -h {hub_rl}
- To run suite:
  scandium-cli suite -i {suite_id} -p {project_id} -k {api key} -t {run type parallel or sequential} -s {screeeshot true | false} -r {retry}  -h {hub_url}
