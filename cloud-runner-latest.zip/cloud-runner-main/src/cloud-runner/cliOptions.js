const { program } = require('commander');

program.name("Scandium Cloud Runner")
  .description("Run your no-code automated tests in the cloud")
  .version("0.0.2");

program
  .option('--test-id <testid>', 'Id of test to run')
  .option('--api-key <apikey>', 'Api key to authenticate account')
  .option('--suite-id <suiteid>', 'Suite Id to run, overrides testid')
  .option('--project-id')
  .option('--headless')
  .option('-s, --separator <char>');

// program.parse();

module.exports = {
  program
}