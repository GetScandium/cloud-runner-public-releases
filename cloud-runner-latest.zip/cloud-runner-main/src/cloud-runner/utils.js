const { Repository, EntityId } = require("redis-om")
const { client } = require("../server/db")
const runSchema = require("../server/db/Runs")

const delay = (fn, timeout) => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            try {
                resolve(fn())
            } catch (e) {
                reject(e)
            }
        }, timeout)
    })
}

const setDateNatively = (target, value) => {
    target.value = value;
    target.dispatchEvent(new Event("change"))
}

async function setFileInputs(target, fileUrls = []) {
    const fileDownload = async (files) => {
        const getBlobFromUrl = async (url) => {
            const response = await fetch(url);
            const blob = await response.blob();
            return blob;
        }

        return await Promise.all(files.map(async ({ url, name }) => {
            const blob = await getBlobFromUrl(url);

            return { blob, name };
        }));
    }

    const blobs = await fileDownload(fileUrls);

    const dt = new DataTransfer();

    const readFileAsArrayBuffer = (blob) => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                resolve(reader.result);
            };
            reader.onerror = reject;
            reader.readAsArrayBuffer(blob);
        });
    };

    for (const blobInfo of blobs) {
        const { blob, name } = blobInfo;
        const arrayBuffer = await readFileAsArrayBuffer(blob);
        const file = new File([arrayBuffer], name, { type: blob.type });
        dt.items.add(file);
    }

    target.files = dt.files;
    target.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    return Promise.resolve(dt);
}

async function dropFiles(target, fileUrls = []) {
    const fileDownload = async (files) => {
        const getBlobFromUrl = async (url) => {
            const response = await fetch(url);
            const blob = await response.blob();
            return blob;
        }

        return await Promise.all(files.map(async ({ url, name }) => {
            const blob = await getBlobFromUrl(url);

            return ({ blob, name });
        }));
    }

    const blobs = await fileDownload(fileUrls);
    const dataTransfer = new DataTransfer();
    let filesToDrop = [];

    // Add the files to the data transfer object
    for(const blob of blobs){
        let file = new File([blob.blob], blob.name, {type: blob.blob.type});
        dataTransfer.items.add(file);
        filesToDrop.push(file);
    }

    const dropEvent = new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer });
    target.dispatchEvent(dropEvent);
    
    return Promise.resolve(dropEvent);
}                                                                                                                                                                     

const tryUntil = (name, check, interval = 1000, expire = 10000, errorMsg) => {
    // console.log(`running ${name} at ${new Date().toString()}`);
    const start = new Date()
    let tries = 0;
    const go = () => {

        if (expire && new Date() - start >= expire) {
            const msg = errorMsg || `until: ${name} expired!`
            throw new Error(msg)
        }
        tries++;
        // console.log(`tries for ${name} = ${tries}`)

        const { pass, result } = check()

        if (pass) return Promise.resolve(result)
        return delay(go, interval)
    }

    return new Promise((resolve, reject) => {
        try {
            resolve(go())
        } catch (e) {
            reject(e)
        }
    })
}

/**
     * The `tryUntil` method requires a function that returns a truthy value or boolean false
     * The `untilfy` method takes a function that can throw errors and make it compatible with the `tryUntil` method
     * Example of this is seen in the `locateElement` method
     */
const untilfy = (fn, ...args) => {
    try {
        let result = fn(...args)
        return result
    } catch (error) {
        return false
    }
}

/**
 * Replace single/double quotes within text to be used for xpath text evaluation
 * @param {String} text Text to escape
 * @returns 
 */
function escapeXPathString(text) {
    if (text.includes("'") && text.includes('"')) {
        // If the text contains both single and double quotes, use concat to escape both
        return `concat('${text.replace(/'/g, "',\"'\",'")}', "")`;
    } else if (text.includes("'")) {
        // If the text contains only single quotes, wrap it in double quotes
        return `"${text}"`;
    } else {
        // If the text contains only double quotes, wrap it in single quotes
        return `'${text}'`;
    }
}

const generateID = function (timestamp) {
    timestamp = timestamp || Date.now();
    return timestamp.toString(36) + Math.random().toString(36).slice(2);
}

/**
 * Check that a text string contains the substring pattern
 * @param {String} pattern Substring/pattern to look for i.e needle
 * @param {String} text String from which to search for substring i.e haystack
 * @returns {Boolean}
 */
function patternMatch(pattern, text) {
    if (pattern.startsWith("/") && pattern.endsWith("/")) {
        let regexPattern = pattern.substring(pattern.indexOf("/") + 1, pattern.lastIndexOf("/"));
        let regex = new RegExp(regexPattern);
        return regex.test(text);
    } else {
        return text.includes(pattern)
    }
}

const getElementByXpath = (xpath) => {
    let externalNamespaceNodes = ['svg', 'path', 'line', 'circle'];
    externalNamespaceNodes.forEach(nsNode => {
        if (xpath.includes(nsNode)) {
            xpath = xpath.replace(`/${nsNode}`, `/*[name()='${nsNode}']`);
        }
    });
    return document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue
}

const isObjectEmpty =  (obj) => {
    return obj.constructor === Object && Object.keys(obj).length === 0
}



const simulateDragDrop = async (driver, sourceNode, destinationNode) => {
    try {
        await driver.actions()
        .dragAndDrop(sourceNode, destinationNode)
        .perform();

        return true;
    } catch (error) {
        throw error;
    }
}

const simulateMouseDragAndDrop = async (driver, elemDrag, destinationCoordinates={x, y}) => {
    
    try {

        await driver.actions().dragAndDrop(elemDrag, { x: Math.round(destinationCoordinates.x), y: Math.round(destinationCoordinates.y) }).perform();

        return true;
    } catch (error) {
        throw error;
    }
}

const simulateNativeMouseDragAndDrop = (elemDrag, destinationCoordinates={x, y}) => {
    // function for triggering mouse events
    var fireMouseEvent = function (type, elem, centerX, centerY) {
      var evt = document.createEvent('MouseEvents')
      evt.initMouseEvent(
        type,
        true,
        true,
        window,
        1,
        1,
        1,
        centerX,
        centerY,
        false,
        false,
        false,
        false,
        0,
        elem
      )
      elem.dispatchEvent(evt)
    }
  
    // fetch target elements
    
    if (!elemDrag) return false
  
    // calculate positions
    var pos = elemDrag.getBoundingClientRect()
    var center1X = Math.floor((pos.left + pos.right) / 2)
    var center1Y = Math.floor((pos.top + pos.bottom) / 2)
    
    var center2X = destinationCoordinates.x;// Math.floor((pos.left + pos.right) / 2)
    var center2Y = destinationCoordinates.y; // Math.floor((pos.top + pos.bottom) / 2)
  
    // mouse over dragged element and mousedown
    fireMouseEvent('mousemove', elemDrag, center1X, center1Y)
    fireMouseEvent('mouseenter', elemDrag, center1X, center1Y)
    fireMouseEvent('mouseover', elemDrag, center1X, center1Y)
    fireMouseEvent('mousedown', elemDrag, center1X, center1Y)
  
    // start dragging process over to drop target
    fireMouseEvent('dragstart', elemDrag, center1X, center1Y)
    fireMouseEvent('drag', elemDrag, center1X, center1Y)
    fireMouseEvent('mousemove', elemDrag, center2X, center2Y)
    fireMouseEvent('drag', elemDrag, center2X, center2Y)
    // fireMouseEvent('mousemove', elemDrop, center2X, center2Y)
  
    // // trigger dragging process on top of drop target
    // fireMouseEvent('mouseenter', elemDrop, center2X, center2Y)
    // fireMouseEvent('dragenter', elemDrop, center2X, center2Y)
    // fireMouseEvent('mouseover', elemDrop, center2X, center2Y)
    // fireMouseEvent('dragover', elemDrop, center2X, center2Y)
  
    // // release dragged element on top of drop target
    // fireMouseEvent('drop', elemDrop, center2X, center2Y)
    fireMouseEvent('dragend', elemDrag, center2X, center2Y)
    fireMouseEvent('mouseup', elemDrag, center2X, center2Y)
  
    return true
  }

module.exports = {
    delay,
    tryUntil,
    untilfy,
    escapeXPathString,
    generateID,
    patternMatch,
    getElementByXpath,
    isObjectEmpty,
    setFileInputs,
    dropFiles,
    simulateDragDrop,
    simulateMouseDragAndDrop,
    simulateNativeMouseDragAndDrop,
    setDateNatively
}
