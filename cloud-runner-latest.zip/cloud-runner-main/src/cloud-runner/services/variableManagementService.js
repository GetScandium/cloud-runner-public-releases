
class RandomValueGenerator {
  defaultAlphaCharacters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
  defaultNumSet = "0123456789";
  defaultAlphaNumCharacters = `${this.defaultAlphaCharacters}${this.defaultNumSet}`;

  generateAlpha(length=10, characterSet){
      let allowedCharacters = characterSet || this.defaultAlphaCharacters;
       
      let result = '';
      const charactersLength = allowedCharacters.length;
      for (let i = 0; i < length; i++) {
          result += allowedCharacters.charAt(Math.floor(Math.random() * charactersLength));
      }

      return result;
  }

  generateAlphaNum(length=10, characterSet){
      let allowedCharacters = characterSet || this.defaultAlphaNumCharacters;
      return this.generateAlpha(length, allowedCharacters)
  }

  generateNumber(length=1){
      const min = Math.pow(10, (length - 1));
      const max = Math.pow(10, (length));
      return Math.floor(Math.random() * (max - min) + min);
  }

  /**
   * Generates a random number within a given range.
   * @param {number} min - The minimum value of the range
   * @param {number} max - The maximum value of the range
   * @returns {number} - A random number within the given range
   */
  generateNumberInRange(min=0, max= typeof max === 'number' ? max : 10){
      min = Number(min);
      max = Number(max)

      if (min == NaN || max == NaN){
          throw new Error(`Both min '${min}' and max '${max} must be numbers`);
      }
      if (min >= max){
          throw new Error(`min '${min}' must be greater than max '${max}'`)
      }
      
      const num = Math.floor(Math.random() * (max - min + 1)) + min;
      return num;
  }

  generateTime(offset=0){
      offset = Number(offset);
      if (typeof offset !== 'number'){
          throw new Error(`The provided offset '${offset}' must be a number`);
      }
      return Date.now() + offset
  }

  generateDate(offset=0, format="DD/MM/YYYY"){
      offset = Number(offset);
      if (typeof offset !== 'number') {
          throw new Error(`The provided offset '${offset}' must be a number. '${typeof offset}' provided`);
      }
      let currentDate = new Date();
      currentDate.setDate(currentDate.getDate() + offset)
      let year = currentDate.getFullYear();
      let month = String(currentDate.getMonth() + 1).padStart(2, '0');
      let day = String(currentDate.getDate()).padStart(2, '0');
      let hours = String(currentDate.getHours()).padStart(2, '0');
      let minutes = String(currentDate.getMinutes()).padStart(2, '0');
      let seconds = String(currentDate.getSeconds()).padStart(2, '0');

      const formattedDate = format
          .replace('YYYY', year)
          .replace('MM', month)
          .replace('DD', day)
          .replace('HH', hours)
          .replace('mm', minutes)
          .replace('ss', seconds);

      return formattedDate;
      // const getSeparator = function(formatString){
      //     return "/";
      // }
      
      // let formattedDate = `${day}${getSeparator()}${month}${getSeparator()}${year}`;
      // return formattedDate;
  }

  generateDateTime(offset=0){
      offset = Number(0);
      if (typeof offset !== 'number'){
          throw new Error(`The provided offset '${offset}' must be a number. '${typeof offset}' provided`);
      }

      const currentDate = new Date();
      const newDate = new Date(currentDate.getTime() + offset);

      const year = newDate.getFullYear();
      const month = String(newDate.getMonth() + 1).padStart(2, '0');
      const day = String(newDate.getDate()).padStart(2, '0');
      const hours = String(newDate.getHours()).padStart(2, '0');
      const minutes = String(newDate.getMinutes()).padStart(2, '0');
      const seconds = String(newDate.getSeconds()).padStart(2, '0');

      const dateTimeString = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
      return dateTimeString;
  }
}

class VariableManager {
  variables = [];
  internalFunctionNames = [
    'alpha', 'alphanum', 'num', 'range', 'date', 'time', 'datetime'
  ];

  set(obj){
    Object.keys(obj).forEach(key => {
        let trimmedKeyChars = key.trim();
        if (trimmedKeyChars.length === 0) return;
        trimmedKeyChars = trimmedKeyChars.toLowerCase();

        //TODO: check if it is valid variable name

        //check if it attempts to overwrite system function
        if (this.internalFunctionNames.includes(trimmedKeyChars)){
            throw new Error(`Naming a variable ${trimmedKeyChars} is not allowed`);
        }

        this.variables[trimmedKeyChars] = new VariableManager().replaceVariableWithValues(obj[key]); ;

    });
  }

  get(key){
    return this.variables[key.toLowerCase()];
  }

  dump(){
    return {...this.variables};
  }

  clear(key){
    delete this.variables[key]
    // Object.keys(this.variables).forEach(key => {
    //     if (reg.test(key)) {
    //         delete vars[key]
    //     }
    // })
  }

  reset(options={retainGlobal: true}){
    if (options.retainGlobal){
        this.variables = globalVariables;
    }else{
        this.variables = [];
      }
  }

  systemVarRegex = /^{{(alpha(\s*\(\s*\d+\s*,*\s*[_a-zA-Z]*\))|num\s*\(\d+\)|range(\(\d+,\s*\d+\))|alphanum(\s*\(\s*\d+\s*,*\s*[_a-zA-Z0-9]*\))|date\(-*\d+\s*,*\s*(?:.*)*\)|datetime\(\d+\)|time(\(*-*\d*\)*))}}$/i;
  /**
   * 
   * @param {string} variable 
   */
  isSystemFunction(variable){
    const regex = this.systemVarRegex;
    return regex.test(variable);
  }

  convertVariableToSystemFunction(variable){
      if (this.isSystemFunction(variable)){
        let varToFunctionMap = {
          'num':'generateNumber',
          'range': 'generateNumberInRange',
          'alpha': 'generateAlpha',
          'alphanum': 'generateAlphaNum',
          'date': 'generateDate',
          'time': 'generateTime',
          'datetime': 'generateDateTime'
        }

        const regex = /(\w+)\s*\((.*?)\)/;
        const match = variable.match(regex);
        if (match){
            const functionName = match[1].toLowerCase();
            const argumentsString = match[2];
            const argumentsArray = argumentsString.split(',').map((arg) => arg.trim());
            if (varToFunctionMap.hasOwnProperty(functionName)){
                let generator = new RandomValueGenerator();
                let generatedValue = generator[varToFunctionMap[functionName]](...argumentsArray)
                return generatedValue;
            }else{
                throw new Error(`Unknown system function '${functionName}'`);
            }
        }
        else{
          throw new Error(`The variable ${variable} does not match any know variable or function`);
        }
      }else{
      let matchedVar = variable.match(/\{\{([^}]+)\}\}/i);
      
      let trimmedVarKey = matchedVar[1]?.trim();
      let storedVar = this.get(trimmedVarKey);
      if (storedVar != null && storedVar != undefined){    
          return storedVar;
      }
      else{
          console.log(`Unknown user-defined variable ${variable}`)
          return variable;
      }
    }
  }
  /**
   * 
   * @param {string} text The text to extract variables from
   */
  extractVariablesFromString(text){
      
    if (text == null || text == undefined) return [];
    try {
        return text.match(/{{(.*?)}}/gi);    
    } catch (error) {
        return `${text}`;
    }
      
  }

  /**
   * Replace all the variable instances in a string with actual values of the variable
   * @param {string} text Full text containing variables
   * @returns {string} updatedText 
   */
  replaceVariableWithValues(text){
      
    if (text == null || text == undefined) return text;
    text = ""+text;
    let variables = this.extractVariablesFromString(text);
    
    if (variables === null || variables.length === 0) return text;
    let updatedText = text+"";
    variables.forEach((variable, index) => {
        updatedText = updatedText.replace(variable, this.convertVariableToSystemFunction(variable))
    })
    return updatedText;
  }
}

module.exports = VariableManager;
