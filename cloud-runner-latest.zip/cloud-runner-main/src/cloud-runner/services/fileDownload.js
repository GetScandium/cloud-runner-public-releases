const { DownloaderHelper } = require('node-downloader-helper');
const path = require("path");
const fs = require("fs")

const filePath = process.env.UPLOAD_DIR || path.join(__dirname, "files");

async function downloadFile(url) {
  return new Promise((resolve, reject) => {
    const dl = new DownloaderHelper(url, filePath);

    dl.on('end', (d) => resolve(d.filePath));
    dl.on('error', (err) => reject(err));
    dl.start().catch(err => reject(err));
  });
}

const deleteFile = (dir) => {
  fs.unlinkSync(dir);
}

module.exports = {
  downloadFile,
  deleteFile
}
