const { Builder, By, Key, until, WebDriver, WebElement, Browser } = require('selenium-webdriver');
const chrome = require('selenium-webdriver/chrome');
const firefox = require('selenium-webdriver/firefox');
const safari = require('selenium-webdriver/safari');
const edge = require('selenium-webdriver/edge');
const logging = require('selenium-webdriver/lib/logging')
logger = logging.getLogger('webdriver')

logger.setLevel(logging.Level.INFO)
logging.installConsoleHandler()

const path = require('path');
const { tryUntil, patternMatch, getElementByXpath, escapeXPathString } = require('./utils');

const keysMapping = {
    Tab: "TAB",
    Enter: "ENTER",
    Escape: "ESCAPE"
}

function getStepDelay(step){
    if (isNaN(step.preStepDelay) || step.preStepDelay < 0){
        return 0;
    }
    if (step.preStepDelay > 600000) return 600000
    return step.preStepDelay;

}

const browsers = ["firefox"];


const driverBuilder = async ({ browser, hubServer, width, height }) => {
    try {
        let driver;
        let options;
        switch (browser) {
            case "chrome":
                options = new chrome.Options();
        
                options.addArguments('--start-maximized');
                
                options.excludeSwitches('enable-logging');
                options.setLoggingPrefs({ browser: 'ALL' });

            driver = await new Builder().forBrowser(Browser.CHROME).setChromeOptions(options).usingServer(hubServer).build();
            (width && height) && await driver.manage().window().setRect({ width: width, height: height });
            break;
        case "firefox":
            options = new firefox.Options();
    
            options.setPreference('browser', 'all');
            // options.setPreference('devtools.console.stdout.content', true);

                driver = await new Builder().forBrowser(Browser.FIREFOX).setFirefoxOptions(options).usingServer(hubServer).build();
                (width && height) && await driver.manage().window().setRect({ width: width, height: height });
                break;
            case "safari":
                options = new safari.Options();

                options.setLoggingPrefs({ browser: "ALL" })
                

                driver = await new Builder().forBrowser(Browser.SAFARI).setSafariOptions(options).usingServer(hubServer).build();
                (width && height) && await driver.manage().window().setRect({ width: width, height: height });
                break;
            case "edge":
                options = new edge.Options();

                options.addArguments('--ignore-certificate-errors');
                
                options.setLoggingPrefs({ browser: "ALL" })

                driver = await new Builder().forBrowser(Browser.EDGE).setSafariOptions(options).usingServer(hubServer).build();
                (width && height) && await driver.manage().window().setRect({ width: width, height: height });
                break;
            default:
                break;
        }

        return driver;
    } catch (error) {
        console.log("Driver initiation: ", error)
        throw error;
    }
}

/**
 * 
 * @param {WebDriver} driver 
 * @param {Object} element 
 * @returns {WebElement}
 * 
 * @throws 
 */

async function findElement(driver, step, mustBeVisible=false, mustBeActionable=false){
    if (step.element && (step.element.selector === "document" || step.element.selector === "window")) {
        let doc = await driver.executeScript("return document.documentElement;");
        return doc;
    }
    
    let selectors = [];
    
    if (step.element.selector){
        selectors.push(By.css(step.element.selector));
    }
    if(step.element.xpathLocator){
        selectors.push(By.xpath(step.element.xpathLocator))
    }
    if (step.element.customSelector != null) {
        if(Array.isArray(step.element.customSelector)){
            for (let index = 0; index < step.element.customSelector.length; index++) {
                const cs = step.element.customSelector[index];
                selectors.push(By.css(cs))
                // console.log(`Pushing sel: ${cs} for step: ${step.title}`)
            }
        }else{
            selectors.push(By.css(step.element.customSelector));
        }
        
    }
    

    let element, using;
    for(const selector of selectors){
        try {
            let elements = await driver.findElements(selector);
            if(elements.length > 1){
                if (step.element.text != "" && step.element.text != null) {
                    let xpath = `//${step.element.tagName}[contains(text(), ${escapeXPathString(step.element.text)})]`;
                    element = await driver.executeScript(getElementByXpath, xpath);
                }
            }else{
                element = elements[0];
            }
            
            break;
        } catch (error) {
            //ignore error so all selectors can be tried

        }
    }
    if (element == null || element == undefined){
        element = await driver.executeScript(getElementByXpath, step.element.xpathLocator);
    }
    if (element == null || element == undefined){
        if (step.element.text != "" && step.element.text != null) {
            let xpath = `//${step.element.tagName}[contains(text(), ${escapeXPathString(step.element.text)})]`;
            element = await driver.executeScript(getElementByXpath, xpath);
        }
    }
    if (element == null || element == undefined){
        return {
            status: false,
            message: "Element not found"
        }
        // throw new ElementNotFoundError();
    }

    if (mustBeActionable == true) {mustBeVisible = true};
    if (mustBeVisible && !element.isDisplayed()){
        console.log(`Element ${element} is found, but not displayed`);
        return {
            status: false,
            message: "Element was found, but it wasn't visible"
        }
    }
    
    let elementIsActionable = await driver.executeScript(isActionable, element);
    
    if (mustBeActionable && ((await element.isEnabled()) !== true || !elementIsActionable)){
        return {
            status: false,
            message: "Element was found, visible, but not actionable"
        }
    }

    const getShadowRoot = (element) => {
        return element.shadowRoot;
    }
    
    const findShadowElement = async () => {
      return driver.executeScript(getShadowRoot, element);
    }

    if (step.element.isShadowDom == true || step.element.shadowSelectors != null){
        const shadowRoot = findShadowElement(element);
        if (shadowRoot !== null){
            //target shadow root host found, so try to get inner shadow root element
            element = shadowRoot.querySelector(element.shadowSelectors.selector);
            if (target == null) {
                //target found as shadow dom element, but inner element not selectable
                throw new Error(`Inner element within shadow-root not found`);
            }
        }else{
            //target was found, but not seen as a shadow dom element, so we will still continue to try to use it as normal
            element = element
        }   
    }
    
    return element;
}

/**
 * Locate a frame on a page
 * @param {WebDriver} driver 
 * @param {*} step 
 */
async function findFrame(driver, framesStack){
    
    let selectors = framesStack
    let locators = [];
    if (selectors.customSelector) {
        locators.push(By.css(selectors.customSelector));
    }
    if (selectors.selector) {
        locators.push(By.css(selectors.selector));
    }
    if (selectors.xpathLocator) {
        locators.push(By.xpath(selectors.xpathLocator))
    }

    let element, using;
    for (const selector of locators) {
        try {
            element = await driver.findElement(selector);
            break;
        } catch (error) {
            //ignore error so all locators can be tried
        }
    }

    if (element){
        return element;
    }

    function findFrameWithProperties(frameStackObject, properties = ['id', 'name', 'src']) {
        let frame;

        for (let i = 0; i < properties.length; i++) {
            const property = properties[i];
            if (frameStackObject[property] == null || frameStackObject[property] == undefined) {
                continue;
            }
            let item = document.querySelector(`[${property}^='${frameStackObject[property]}']`);
            if (item != null) {
                //Element was found, might be frame, might not be
                frame = item;
                usedSelector = property
            }
        }

        return frame;
    }

    let properties = ['id', 'name', 'src'];
    let frame = await driver.executeScript(findFrameWithProperties, framesStack, properties);
    if (frame != null){
        return frame;
    }else{
        return {
            status: false,
            message: `Frame was not found on page`
        }
    }
}

const runPreconditionCheck = async (driver, step) => {
  if (step.conditions === undefined || !Array.isArray(step.conditions) || step.conditions.length < 1){
      //always run
    return {status: true, reason: "Always run"};
  }
  let conditions = step.conditions || [];
  let condition = conditions[0];
  
  if (condition.type == "skip"){
    return {status: false, reason: "Never run"};
  }
  if (condition.type == "element"){
    try {
      driver.wait(async (driver) => {
        let result = await findElement(driver, condition);
        // console.log("Element in inner frame", await result.getTagName())
        return {
          pass: !!result,
          result
        };
        // throw new Error(result.message)
    }, step.stepTimeout || 500, null)
    
    if (condition.visibility === 'visible'){
      return {status: true, reason: "Element found"};
    }
    if (condition.visibility === 'not-visible'){
      return {status: false, reason: `Found element when it is expected to not be present`};
    }
    if (condition.subType === 'text'){
      // if (!new RegExp(condition.text).test(el.innerText)){
      if (!patternMatch(condition.text, el.innerText)){
          return {
              status: false,
              reason: `Text do not match, \nExpected: ${condition.text}; found ${el.innerText}`
          }
      }
      return { status: true, reason: `Text correctly match, \nExpected: ${condition.text}; found ${el.innerText}` };
    }
    } catch (error) {
      if (condition.visibility == 'not-visible') {
        return {status: true, reason: "Element is correctly not present"};
      }
      console.log(error);
      return {status: false, reason: "Element not present"};
    }
  }
  
  if (condition.type === "url"){
    try {
      let pageUrl = await driver.getCurrentUrl()
      // if (!pattern.test(pageUrl)){
      if (!patternMatch(condition.urlPattern, pageUrl)){
          return {status: false, reason: `Url do not match. Expected ${condition.urlPattern}; found ${pageUrl}`}
      }
      return {status: true, reason: "Page url matches"};
    } catch (error) {
      return { status: false, reason: error.message }
    }
  }
  if (condition.type === "title"){
    try {
      const title = await driver.getTitle()
      if (!patternMatch(condition.pageTitle, document.title)){
        return {status: false, reason: `Page title do not match. Expected ${condition.pageTitle}; found ${document.title}`};
      }
      return {status: true, reason: "Page title matches"}
    } catch (error) {
      return { status: false, reason: error.message }
    }
  }
  
  return {status: true, reason: "Unknown condition " + condition.type};
}


/**
 * Get the Id of the tab to play
 * @param {WebDriver} driver
 * @param {object} step 
 * @returns Promise tabId integer
 */
const getTabToPlay = async (driver, step) => {
    let existingTabs = await driver.getAllWindowHandles();
    if (step.type === "group") {
        return Promise.resolve(player?.last_play_tab?.id);
    }
    let tabPosition = step.tabDetails.position;
    let attempts = 0;
    return tryUntil("Get tab to play", function () {

        attempts += 1;

        return {
            pass: existingTabs[tabPosition] != undefined,
            result: existingTabs[tabPosition]
        }
    }, 1000, 5000).then(tab => {
        return new Promise((resolve, reject) => {
            return resolve(tab)
        })
    }).catch(async err => {
        console.log("Didn't find tab to play", err);
        //we will assume this tab was a part of the tabs recorded, and now go on to create the tab
        await driver.switchTo().newWindow('tab');
        let allWindows = await driver.getAllWindowHandles();
        let newWindowHandle = allWindows[step.tabDetails.position];
        
        return newWindowHandle;
    })
}

/**
 * 
 * @param {WebElement} element 
 * @returns {void}
 */
function scrollIntoViewIfNecessary(element, isWithinViewport) {
    if (!isWithinViewport(element)) {
        element.scrollIntoView()
    }

    /**
 * Check if element is within viewport
 * @param {WebElement} element 
 * @returns {Boolean}
 */
    function isWithinViewport(element) {
        
        const rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }
}

function jsClick(element, modifiers){
    ;["pointerdown", "mousedown", "mouseup", "pointerup", "click"].forEach(ev => {
        element.dispatchEvent(new MouseEvent(ev, modifiers))
    });
}

let pretendAlertConfirmPromptDialogs = (promptAnswer="custom prompt answer") => {
    // console.log("pretending alert boxes")
    if (!window.oldAlert) window.oldAlert = window.alert
    if (!window.oldConfirm) window.oldConfirm = window.confirm
    if (!window.oldPrompt) window.oldPrompt = window.prompt
    window.alert = function (str) {
        document.body.setAttribute('data-alert', str)
        let alertText = document.createElement("div");
        alertText.innerText = str;
        alertText.style = "display:none";
        alertText.className = "sc__alert_display";
        document.body.appendChild(alertText)
    }
    window.confirm = function (str) {
        document.body.setAttribute('data-confirm', str)
        let alertText = document.createElement("div");
        alertText.innerText = str;
        alertText.style = "display:none";
        alertText.className = "sc__confirm_display";
        document.body.appendChild(alertText)
        return true
    }
    window.prompt = function (str) {
        var answer = promptAnswer || document.body.getAttribute('data-prompt-answer')
        document.body.setAttribute('data-prompt', str)
        document.body.setAttribute('data-prompt-answer', answer);
        let alertText = document.createElement("div");
        alertText.innerText = str;
        alertText.style = "display:none";
        alertText.className = "sc__prompt_display";
        document.body.appendChild(alertText)
        return answer
    }
}

let restoreAlertConfirmPromptDialogs = () => {
    if (window.oldAlert) window.alert = window.oldAlert
    if (window.oldConfirm) window.confirm = window.oldConfirm
    if (window.oldPrompt) window.prompt = window.oldPrompt
}

function isActionable (el) {
    if (el == window || el === document) return true;
    if (!el) return true;

    const style = window.getComputedStyle(el);
    if (el.readonly) {
        return false;
    }
    if (el.disabled) {
        return false;
    }
    if (style.display == "none" || style.opacity == '0' || style.visibility == "hidden" || style.width == '0' || style.height == '0') {
        return false;
    }
    return isActionable(el.parentNode);
}

module.exports = {
    driverBuilder, getStepDelay, getTabToPlay, pretendAlertConfirmPromptDialogs, runPreconditionCheck,
    findElement, findFrame, scrollIntoViewIfNecessary, jsClick, keysMapping
}
