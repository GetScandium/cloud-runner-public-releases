
const { DownloaderHelper } = require('node-downloader-helper');
const dl = new DownloaderHelper('http://res.cloudinary.com/dyhmxy1no/image/upload/v1704264140/step_screenshots/g4fvbhbzztctunmuc2nd.png', __dirname);

dl.on('end', (d) => console.log('Download Completed', d));
dl.on('error', (err) => console.log('Download Failed', err));
dl.start().catch(err => console.error(err));
