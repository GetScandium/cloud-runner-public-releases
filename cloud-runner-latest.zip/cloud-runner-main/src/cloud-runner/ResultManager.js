const { generateID } = require("./utils");

class ResultManager{
    stepResult;
    testResult;
    suiteResult;
    initializeStepResult(step){
        this.stepResult = {
            id: step.id,
            start_timestamp: Date.now(),
            parentStepId: step.parentStepId,
            onError: step.onError,
            error: step.error,
            step_id: step.id,
            title: step.title,
            type: step.type,
            running_status: step.running_status
        }
        return this.stepResult
    }
    initializeTestResult(deviceContext) {
        this.testResult = {
            id: generateID(),
            starting_url: null,
            source: "remote",
            browser: deviceContext.browser,
            browser_version: deviceContext.browserMajorVersion,
            operating_system: deviceContext.os,
            operating_system_version: deviceContext.osVersion,
            is_mobile: deviceContext.mobile,
            duration: 0,
            started_at: 0,
            finished_at: 0,
            status: null,
            running_status: "pending", //completed
            steps: [],
            test_id: null,
            name: null,
        }
        return this.testResult
    }

    initializeSuiteResult(deviceContext) {
        this.suiteResult = {
            id: generateID(),
            starting_url: null,
            source: "remote",
            browser: deviceContext.browser,
            browser_version: deviceContext.browserMajorVersion,
            operating_system: deviceContext.os,
            operating_system_version: deviceContext.osVersion,
            is_mobile: deviceContext.mobile,
            duration: 0,
            started_at: 0,
            finished_at: 0,
            type: player.suite != null ? "suite" : "test-case",
            type_id: player.suite != null ? player.suite.id : player.current_test.id,
            name: `${player.suite?.name ?? player.current_test.name}`,
            status: null,
            running_status: "running", //completed
            results: []
        }
        return this.suiteResult;
    }
}

module.exports = {
    ResultManager
}