const { ec2, iam, autoscaling } = require('@pulumi/aws');
const pulumi = require('@pulumi/pulumi');
const automation = require('@pulumi/pulumi/automation');


class PulumiService {

  stack;

  projectName = "cloud-test-runner"

  initializeStack = async (stackName, browsers) => {
    this.stack = await automation.LocalWorkspace.createOrSelectStack({
      stackName,
      projectName: this.projectName,
      program: () => this.program(browsers)
    });
  }
  // Function to create or update the Pulumi stack
  createOrUpdateStack = async (config, stackName) => {
    // Create or select a stack

    // Set config values
    await this.stack.setConfig('aws:region', { value: config.region || 'us-east-1' });
    await this.stack.setConfig('aws:profile', { value: config.region || 'omoalfa-scandium' });
    await this.stack.setConfig('amiId', { value: config.amiId || 'ami-0230bd60aa48260c6' });
    await this.stack.setConfig('instanceType', { value: config.instanceType || 't2.micro' });

    // Preview and deploy
    const upResult = await this.stack.up({ onOutput: (out) => {
      /// send to backend::::::
      console.log("console", out);
    } })

    return { stackName, data: upResult };
  }

    // Set up Pulumi program
  program = async (browsers) => {

    const amiId = 'ami-0230bd60aa48260c6';
    const instanceType = 't2.micro';
    // Create a VPC
    const vpc = new ec2.Vpc('selenium-vpc', {
        cidrBlock: '10.0.0.0/16',
    });

    const subnetA = new ec2.Subnet("selenium-subnet-a", {
      vpcId: vpc.id,
      cidrBlock: "10.0.1.0/24",
      availabilityZone: "us-east-1b",
    });

    const internetGateway = new ec2.InternetGateway("selenium-igw", {
      vpcId: vpc.id,
    });

    const publicRouteTable = new ec2.RouteTable("public-route-table", {
      vpcId: vpc.id,
      routes: [{
          cidrBlock: "0.0.0.0/0",
          gatewayId: internetGateway.id,
      }],
    });

    const subnetARouteAssociation = new ec2.RouteTableAssociation("subnetA-route-association", {
      subnetId: subnetA.id,
      routeTableId: publicRouteTable.id,
    });

    // Create security groups for hub and nodes
    const hubSecurityGroup = new ec2.SecurityGroup('hub-security-group', {
        vpcId: vpc.id,
        ingress: [
            { protocol: 'tcp', fromPort: 4444, toPort: 4444, cidrBlocks: ['0.0.0.0/0'] },
            // Add any other required ingress rules
        ],
        egress: [
            { protocol: '-1', fromPort: 0, toPort: 0, cidrBlocks: ['0.0.0.0/0'] },
        ],
    });

    const nodeSecurityGroup = new ec2.SecurityGroup('node-security-group', {
        vpcId: vpc.id,
        ingress: [
            { protocol: 'tcp', fromPort: 5555, toPort: 5555, securityGroups: [hubSecurityGroup.id] },
            // Add any other required ingress rules
        ],
        egress: [
            { protocol: '-1', fromPort: 0, toPort: 0, cidrBlocks: ['0.0.0.0/0'] },
        ],
    });

    const hubInstance = new ec2.Instance("hub-instance", {
      ami: amiId, // Specify the desired AMI ID
      instanceType: "t2.micro", // Specify the desired instance type
      subnetId: subnetA.id,
      associatePublicIpAddress: true,
      securityGroupIds: [hubSecurityGroup.id],
      userData: pulumi.interpolate`#!/bin/bash
        yum update -y
        amazon-linux-extras install docker
        service docker start
        usermod -a -G docker ec2-user
        docker run -d -p 4444:4444 --name selenium-hub selenium/hub
      `,
    });

    const hubIp = hubInstance.publicIp

    const nodeInstance = new ec2.Instance("node-instance", {
      ami: amiId, // Specify the Windows AMI ID
      instanceType: "t2.micro", // Specify the desired instance type
      subnetId: subnetA.id,
      associatePublicIpAddress: true,
      securityGroupIds: [nodeSecurityGroup.id],
      userData: pulumi.interpolate`#!/bin/bash
      # Install Docker
      yum update -y
      amazon-linux-extras install docker
      service docker start
      usermod -a -G docker ec2-user

      ${browsers.map(browser => `
        # Start Selenium node for ${browser}
        docker run -d selenium/node-${browser} \
          --link selenium-hub:hub \
          -e HUB_HOST=${hubIp}:4444 \
          -e HUB_PORT=4444
        `).join('\n')}
      `,
    });

    return {
      hubIp: hubInstance.publicIp
    }
  };

  removeStack = async (stackName) => {
    await this.stack.destroy({ onOutput: console.info });
    await this.stack.workspace.removeStack(stackName);
  }
  
}

module.exports = PulumiService;

