
const authMiddleware = (req, res, next) => {
  const api_token = req.headers['x-api-token']

  if (!api_token) return res.status(401).json({ message: "Unauthorized user" });

  req.api_token = api_token;
  return next();
}

module.exports = {
  authMiddleware
}
